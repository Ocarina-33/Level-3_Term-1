
// Generated from CSubset_2205126.g4 by ANTLR 4.13.2

#pragma once


#include "antlr4-runtime.h"
#include "CSubset_2205126Parser.h"



/**
 * This class defines an abstract visitor for a parse tree
 * produced by CSubset_2205126Parser.
 */
class  CSubset_2205126Visitor : public antlr4::tree::AbstractParseTreeVisitor {
public:

  /**
   * Visit parse trees produced by CSubset_2205126Parser.
   */
    virtual std::any visitStart(CSubset_2205126Parser::StartContext *context) = 0;

    virtual std::any visitSingleUnit(CSubset_2205126Parser::SingleUnitContext *context) = 0;

    virtual std::any visitProgUnit(CSubset_2205126Parser::ProgUnitContext *context) = 0;

    virtual std::any visitUnitVarDecl(CSubset_2205126Parser::UnitVarDeclContext *context) = 0;

    virtual std::any visitUnitFuncDecl(CSubset_2205126Parser::UnitFuncDeclContext *context) = 0;

    virtual std::any visitUnitFuncDef(CSubset_2205126Parser::UnitFuncDefContext *context) = 0;

    virtual std::any visitFuncDeclWithParams(CSubset_2205126Parser::FuncDeclWithParamsContext *context) = 0;

    virtual std::any visitFuncDeclNoParams(CSubset_2205126Parser::FuncDeclNoParamsContext *context) = 0;

    virtual std::any visitFuncDefWithParams(CSubset_2205126Parser::FuncDefWithParamsContext *context) = 0;

    virtual std::any visitFuncDefNoParams(CSubset_2205126Parser::FuncDefNoParamsContext *context) = 0;

    virtual std::any visitParamListErrorSubMultiple(CSubset_2205126Parser::ParamListErrorSubMultipleContext *context) = 0;

    virtual std::any visitParamListSingle(CSubset_2205126Parser::ParamListSingleContext *context) = 0;

    virtual std::any visitParamListMultipleNoID(CSubset_2205126Parser::ParamListMultipleNoIDContext *context) = 0;

    virtual std::any visitParamListMultiple(CSubset_2205126Parser::ParamListMultipleContext *context) = 0;

    virtual std::any visitParamListSingleNoID(CSubset_2205126Parser::ParamListSingleNoIDContext *context) = 0;

    virtual std::any visitParamListErrorSub(CSubset_2205126Parser::ParamListErrorSubContext *context) = 0;

    virtual std::any visitCompoundStmtWithBody(CSubset_2205126Parser::CompoundStmtWithBodyContext *context) = 0;

    virtual std::any visitCompoundStmtEmpty(CSubset_2205126Parser::CompoundStmtEmptyContext *context) = 0;

    virtual std::any visitVarDecl(CSubset_2205126Parser::VarDeclContext *context) = 0;

    virtual std::any visitTypeInt(CSubset_2205126Parser::TypeIntContext *context) = 0;

    virtual std::any visitTypeFloat(CSubset_2205126Parser::TypeFloatContext *context) = 0;

    virtual std::any visitTypeVoid(CSubset_2205126Parser::TypeVoidContext *context) = 0;

    virtual std::any visitDeclListSingle(CSubset_2205126Parser::DeclListSingleContext *context) = 0;

    virtual std::any visitDeclListMultipleArray(CSubset_2205126Parser::DeclListMultipleArrayContext *context) = 0;

    virtual std::any visitDeclListMultiple(CSubset_2205126Parser::DeclListMultipleContext *context) = 0;

    virtual std::any visitDeclListSingleArray(CSubset_2205126Parser::DeclListSingleArrayContext *context) = 0;

    virtual std::any visitDeclListErrorSub(CSubset_2205126Parser::DeclListErrorSubContext *context) = 0;

    virtual std::any visitDeclListErrorSubMultiple(CSubset_2205126Parser::DeclListErrorSubMultipleContext *context) = 0;

    virtual std::any visitStmtsSingle(CSubset_2205126Parser::StmtsSingleContext *context) = 0;

    virtual std::any visitStmtsMultiple(CSubset_2205126Parser::StmtsMultipleContext *context) = 0;

    virtual std::any visitStmtVarDecl(CSubset_2205126Parser::StmtVarDeclContext *context) = 0;

    virtual std::any visitStmtExpr(CSubset_2205126Parser::StmtExprContext *context) = 0;

    virtual std::any visitStmtCompound(CSubset_2205126Parser::StmtCompoundContext *context) = 0;

    virtual std::any visitStmtFor(CSubset_2205126Parser::StmtForContext *context) = 0;

    virtual std::any visitStmtIfElse(CSubset_2205126Parser::StmtIfElseContext *context) = 0;

    virtual std::any visitStmtIf(CSubset_2205126Parser::StmtIfContext *context) = 0;

    virtual std::any visitStmtWhile(CSubset_2205126Parser::StmtWhileContext *context) = 0;

    virtual std::any visitStmtPrint(CSubset_2205126Parser::StmtPrintContext *context) = 0;

    virtual std::any visitStmtReturn(CSubset_2205126Parser::StmtReturnContext *context) = 0;

    virtual std::any visitStmtGoto(CSubset_2205126Parser::StmtGotoContext *context) = 0;

    virtual std::any visitStmtLabel(CSubset_2205126Parser::StmtLabelContext *context) = 0;

    virtual std::any visitExprStmtEmpty(CSubset_2205126Parser::ExprStmtEmptyContext *context) = 0;

    virtual std::any visitExprStmtExpr(CSubset_2205126Parser::ExprStmtExprContext *context) = 0;

    virtual std::any visitExprStmtMissingSemicolon(CSubset_2205126Parser::ExprStmtMissingSemicolonContext *context) = 0;

    virtual std::any visitVarId(CSubset_2205126Parser::VarIdContext *context) = 0;

    virtual std::any visitVarArray(CSubset_2205126Parser::VarArrayContext *context) = 0;

    virtual std::any visitExprLogic(CSubset_2205126Parser::ExprLogicContext *context) = 0;

    virtual std::any visitExprAssign(CSubset_2205126Parser::ExprAssignContext *context) = 0;

    virtual std::any visitLogicRel(CSubset_2205126Parser::LogicRelContext *context) = 0;

    virtual std::any visitLogicOp(CSubset_2205126Parser::LogicOpContext *context) = 0;

    virtual std::any visitRelSimple(CSubset_2205126Parser::RelSimpleContext *context) = 0;

    virtual std::any visitRelOp(CSubset_2205126Parser::RelOpContext *context) = 0;

    virtual std::any visitSimpTerm(CSubset_2205126Parser::SimpTermContext *context) = 0;

    virtual std::any visitSimpAdd(CSubset_2205126Parser::SimpAddContext *context) = 0;

    virtual std::any visitTermUnary(CSubset_2205126Parser::TermUnaryContext *context) = 0;

    virtual std::any visitTermMul(CSubset_2205126Parser::TermMulContext *context) = 0;

    virtual std::any visitUnaryAdd(CSubset_2205126Parser::UnaryAddContext *context) = 0;

    virtual std::any visitUnaryNot(CSubset_2205126Parser::UnaryNotContext *context) = 0;

    virtual std::any visitUnaryFactor(CSubset_2205126Parser::UnaryFactorContext *context) = 0;

    virtual std::any visitFactorVar(CSubset_2205126Parser::FactorVarContext *context) = 0;

    virtual std::any visitFactorFuncCall(CSubset_2205126Parser::FactorFuncCallContext *context) = 0;

    virtual std::any visitFactorParen(CSubset_2205126Parser::FactorParenContext *context) = 0;

    virtual std::any visitFactorInt(CSubset_2205126Parser::FactorIntContext *context) = 0;

    virtual std::any visitFactorFloat(CSubset_2205126Parser::FactorFloatContext *context) = 0;

    virtual std::any visitFactorInc(CSubset_2205126Parser::FactorIncContext *context) = 0;

    virtual std::any visitFactorDec(CSubset_2205126Parser::FactorDecContext *context) = 0;

    virtual std::any visitArgListArgs(CSubset_2205126Parser::ArgListArgsContext *context) = 0;

    virtual std::any visitArgListEmpty(CSubset_2205126Parser::ArgListEmptyContext *context) = 0;

    virtual std::any visitArgsSingle(CSubset_2205126Parser::ArgsSingleContext *context) = 0;

    virtual std::any visitArgsMultiple(CSubset_2205126Parser::ArgsMultipleContext *context) = 0;


};

