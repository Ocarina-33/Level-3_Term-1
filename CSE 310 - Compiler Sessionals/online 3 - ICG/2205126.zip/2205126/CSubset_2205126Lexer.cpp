
    #pragma once
    #include <iostream>
    #include <fstream>
    #include <string>

    extern std::ofstream lexLogFile;


// Generated from CSubset_2205126.g4 by ANTLR 4.13.2


#include "CSubset_2205126Lexer.h"


using namespace antlr4;



using namespace antlr4;

namespace {

struct CSubset_2205126LexerStaticData final {
  CSubset_2205126LexerStaticData(std::vector<std::string> ruleNames,
                          std::vector<std::string> channelNames,
                          std::vector<std::string> modeNames,
                          std::vector<std::string> literalNames,
                          std::vector<std::string> symbolicNames)
      : ruleNames(std::move(ruleNames)), channelNames(std::move(channelNames)),
        modeNames(std::move(modeNames)), literalNames(std::move(literalNames)),
        symbolicNames(std::move(symbolicNames)),
        vocabulary(this->literalNames, this->symbolicNames) {}

  CSubset_2205126LexerStaticData(const CSubset_2205126LexerStaticData&) = delete;
  CSubset_2205126LexerStaticData(CSubset_2205126LexerStaticData&&) = delete;
  CSubset_2205126LexerStaticData& operator=(const CSubset_2205126LexerStaticData&) = delete;
  CSubset_2205126LexerStaticData& operator=(CSubset_2205126LexerStaticData&&) = delete;

  std::vector<antlr4::dfa::DFA> decisionToDFA;
  antlr4::atn::PredictionContextCache sharedContextCache;
  const std::vector<std::string> ruleNames;
  const std::vector<std::string> channelNames;
  const std::vector<std::string> modeNames;
  const std::vector<std::string> literalNames;
  const std::vector<std::string> symbolicNames;
  const antlr4::dfa::Vocabulary vocabulary;
  antlr4::atn::SerializedATNView serializedATN;
  std::unique_ptr<antlr4::atn::ATN> atn;
};

::antlr4::internal::OnceFlag csubset_2205126lexerLexerOnceFlag;
#if ANTLR4_USE_THREAD_LOCAL_CACHE
static thread_local
#endif
std::unique_ptr<CSubset_2205126LexerStaticData> csubset_2205126lexerLexerStaticData = nullptr;

void csubset_2205126lexerLexerInitialize() {
#if ANTLR4_USE_THREAD_LOCAL_CACHE
  if (csubset_2205126lexerLexerStaticData != nullptr) {
    return;
  }
#else
  assert(csubset_2205126lexerLexerStaticData == nullptr);
#endif
  auto staticData = std::make_unique<CSubset_2205126LexerStaticData>(
    std::vector<std::string>{
      "LINE_COMMENT", "BLOCK_COMMENT", "STRING", "WS", "IF", "ELSE", "FOR", 
      "GOTO", "WHILE", "PRINTLN", "RETURN", "INT", "FLOAT", "VOID", "LPAREN", 
      "RPAREN", "LCURL", "RCURL", "LTHIRD", "RTHIRD", "SEMICOLON", "COMMA", 
      "COLON", "ADDOP", "MULOP", "INCOP", "DECOP", "NOT", "RELOP", "LOGICOP", 
      "ASSIGNOP", "ID", "LABEL", "CONST_INT", "CONST_FLOAT"
    },
    std::vector<std::string>{
      "DEFAULT_TOKEN_CHANNEL", "HIDDEN"
    },
    std::vector<std::string>{
      "DEFAULT_MODE"
    },
    std::vector<std::string>{
      "", "", "", "", "", "'if'", "'else'", "'for'", "'goto'", "'while'", 
      "'println'", "'return'", "'int'", "'float'", "'void'", "'('", "')'", 
      "'{'", "'}'", "'['", "']'", "';'", "','", "':'", "", "", "'++'", "'--'", 
      "'!'", "", "", "'='"
    },
    std::vector<std::string>{
      "", "LINE_COMMENT", "BLOCK_COMMENT", "STRING", "WS", "IF", "ELSE", 
      "FOR", "GOTO", "WHILE", "PRINTLN", "RETURN", "INT", "FLOAT", "VOID", 
      "LPAREN", "RPAREN", "LCURL", "RCURL", "LTHIRD", "RTHIRD", "SEMICOLON", 
      "COMMA", "COLON", "ADDOP", "MULOP", "INCOP", "DECOP", "NOT", "RELOP", 
      "LOGICOP", "ASSIGNOP", "ID", "LABEL", "CONST_INT", "CONST_FLOAT"
    }
  );
  static const int32_t serializedATNSegment[] = {
  	4,0,35,282,6,-1,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
  	6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,2,14,
  	7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,7,20,2,21,
  	7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,2,27,7,27,2,28,
  	7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,7,33,2,34,7,34,1,0,
  	1,0,1,0,1,0,5,0,76,8,0,10,0,12,0,79,9,0,1,0,1,0,1,0,1,0,1,1,1,1,1,1,1,
  	1,1,1,5,1,90,8,1,10,1,12,1,93,9,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,2,
  	1,2,1,2,5,2,106,8,2,10,2,12,2,109,9,2,1,2,1,2,1,2,1,2,1,2,1,3,4,3,117,
  	8,3,11,3,12,3,118,1,3,1,3,1,4,1,4,1,4,1,5,1,5,1,5,1,5,1,5,1,6,1,6,1,6,
  	1,6,1,7,1,7,1,7,1,7,1,7,1,8,1,8,1,8,1,8,1,8,1,8,1,9,1,9,1,9,1,9,1,9,1,
  	9,1,9,1,9,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,11,1,11,1,11,1,11,1,12,
  	1,12,1,12,1,12,1,12,1,12,1,13,1,13,1,13,1,13,1,13,1,14,1,14,1,15,1,15,
  	1,16,1,16,1,17,1,17,1,18,1,18,1,19,1,19,1,20,1,20,1,21,1,21,1,22,1,22,
  	1,23,1,23,1,24,1,24,1,25,1,25,1,25,1,26,1,26,1,26,1,27,1,27,1,28,1,28,
  	1,28,1,28,1,28,1,28,1,28,1,28,1,28,3,28,215,8,28,1,29,1,29,1,29,1,29,
  	3,29,221,8,29,1,30,1,30,1,31,1,31,5,31,227,8,31,10,31,12,31,230,9,31,
  	1,32,1,32,5,32,234,8,32,10,32,12,32,237,9,32,1,33,4,33,240,8,33,11,33,
  	12,33,241,1,34,4,34,245,8,34,11,34,12,34,246,1,34,1,34,5,34,251,8,34,
  	10,34,12,34,254,9,34,3,34,256,8,34,1,34,1,34,3,34,260,8,34,1,34,4,34,
  	263,8,34,11,34,12,34,264,3,34,267,8,34,1,34,1,34,4,34,271,8,34,11,34,
  	12,34,272,1,34,4,34,276,8,34,11,34,12,34,277,1,34,3,34,281,8,34,1,91,
  	0,35,1,1,3,2,5,3,7,4,9,5,11,6,13,7,15,8,17,9,19,10,21,11,23,12,25,13,
  	27,14,29,15,31,16,33,17,35,18,37,19,39,20,41,21,43,22,45,23,47,24,49,
  	25,51,26,53,27,55,28,57,29,59,30,61,31,63,32,65,33,67,34,69,35,1,0,10,
  	2,0,10,10,13,13,4,0,10,10,13,13,34,34,92,92,3,0,9,10,12,13,32,32,2,0,
  	43,43,45,45,3,0,37,37,42,42,47,47,2,0,60,60,62,62,3,0,65,90,95,95,97,
  	122,4,0,48,57,65,90,95,95,97,122,1,0,48,57,2,0,69,69,101,101,305,0,1,
  	1,0,0,0,0,3,1,0,0,0,0,5,1,0,0,0,0,7,1,0,0,0,0,9,1,0,0,0,0,11,1,0,0,0,
  	0,13,1,0,0,0,0,15,1,0,0,0,0,17,1,0,0,0,0,19,1,0,0,0,0,21,1,0,0,0,0,23,
  	1,0,0,0,0,25,1,0,0,0,0,27,1,0,0,0,0,29,1,0,0,0,0,31,1,0,0,0,0,33,1,0,
  	0,0,0,35,1,0,0,0,0,37,1,0,0,0,0,39,1,0,0,0,0,41,1,0,0,0,0,43,1,0,0,0,
  	0,45,1,0,0,0,0,47,1,0,0,0,0,49,1,0,0,0,0,51,1,0,0,0,0,53,1,0,0,0,0,55,
  	1,0,0,0,0,57,1,0,0,0,0,59,1,0,0,0,0,61,1,0,0,0,0,63,1,0,0,0,0,65,1,0,
  	0,0,0,67,1,0,0,0,0,69,1,0,0,0,1,71,1,0,0,0,3,84,1,0,0,0,5,101,1,0,0,0,
  	7,116,1,0,0,0,9,122,1,0,0,0,11,125,1,0,0,0,13,130,1,0,0,0,15,134,1,0,
  	0,0,17,139,1,0,0,0,19,145,1,0,0,0,21,153,1,0,0,0,23,160,1,0,0,0,25,164,
  	1,0,0,0,27,170,1,0,0,0,29,175,1,0,0,0,31,177,1,0,0,0,33,179,1,0,0,0,35,
  	181,1,0,0,0,37,183,1,0,0,0,39,185,1,0,0,0,41,187,1,0,0,0,43,189,1,0,0,
  	0,45,191,1,0,0,0,47,193,1,0,0,0,49,195,1,0,0,0,51,197,1,0,0,0,53,200,
  	1,0,0,0,55,203,1,0,0,0,57,214,1,0,0,0,59,220,1,0,0,0,61,222,1,0,0,0,63,
  	224,1,0,0,0,65,231,1,0,0,0,67,239,1,0,0,0,69,280,1,0,0,0,71,72,5,47,0,
  	0,72,73,5,47,0,0,73,77,1,0,0,0,74,76,8,0,0,0,75,74,1,0,0,0,76,79,1,0,
  	0,0,77,75,1,0,0,0,77,78,1,0,0,0,78,80,1,0,0,0,79,77,1,0,0,0,80,81,6,0,
  	0,0,81,82,1,0,0,0,82,83,6,0,1,0,83,2,1,0,0,0,84,85,5,47,0,0,85,86,5,42,
  	0,0,86,91,1,0,0,0,87,90,9,0,0,0,88,90,7,0,0,0,89,87,1,0,0,0,89,88,1,0,
  	0,0,90,93,1,0,0,0,91,92,1,0,0,0,91,89,1,0,0,0,92,94,1,0,0,0,93,91,1,0,
  	0,0,94,95,5,42,0,0,95,96,5,47,0,0,96,97,1,0,0,0,97,98,6,1,2,0,98,99,1,
  	0,0,0,99,100,6,1,1,0,100,4,1,0,0,0,101,107,5,34,0,0,102,103,5,92,0,0,
  	103,106,9,0,0,0,104,106,8,1,0,0,105,102,1,0,0,0,105,104,1,0,0,0,106,109,
  	1,0,0,0,107,105,1,0,0,0,107,108,1,0,0,0,108,110,1,0,0,0,109,107,1,0,0,
  	0,110,111,5,34,0,0,111,112,6,2,3,0,112,113,1,0,0,0,113,114,6,2,1,0,114,
  	6,1,0,0,0,115,117,7,2,0,0,116,115,1,0,0,0,117,118,1,0,0,0,118,116,1,0,
  	0,0,118,119,1,0,0,0,119,120,1,0,0,0,120,121,6,3,1,0,121,8,1,0,0,0,122,
  	123,5,105,0,0,123,124,5,102,0,0,124,10,1,0,0,0,125,126,5,101,0,0,126,
  	127,5,108,0,0,127,128,5,115,0,0,128,129,5,101,0,0,129,12,1,0,0,0,130,
  	131,5,102,0,0,131,132,5,111,0,0,132,133,5,114,0,0,133,14,1,0,0,0,134,
  	135,5,103,0,0,135,136,5,111,0,0,136,137,5,116,0,0,137,138,5,111,0,0,138,
  	16,1,0,0,0,139,140,5,119,0,0,140,141,5,104,0,0,141,142,5,105,0,0,142,
  	143,5,108,0,0,143,144,5,101,0,0,144,18,1,0,0,0,145,146,5,112,0,0,146,
  	147,5,114,0,0,147,148,5,105,0,0,148,149,5,110,0,0,149,150,5,116,0,0,150,
  	151,5,108,0,0,151,152,5,110,0,0,152,20,1,0,0,0,153,154,5,114,0,0,154,
  	155,5,101,0,0,155,156,5,116,0,0,156,157,5,117,0,0,157,158,5,114,0,0,158,
  	159,5,110,0,0,159,22,1,0,0,0,160,161,5,105,0,0,161,162,5,110,0,0,162,
  	163,5,116,0,0,163,24,1,0,0,0,164,165,5,102,0,0,165,166,5,108,0,0,166,
  	167,5,111,0,0,167,168,5,97,0,0,168,169,5,116,0,0,169,26,1,0,0,0,170,171,
  	5,118,0,0,171,172,5,111,0,0,172,173,5,105,0,0,173,174,5,100,0,0,174,28,
  	1,0,0,0,175,176,5,40,0,0,176,30,1,0,0,0,177,178,5,41,0,0,178,32,1,0,0,
  	0,179,180,5,123,0,0,180,34,1,0,0,0,181,182,5,125,0,0,182,36,1,0,0,0,183,
  	184,5,91,0,0,184,38,1,0,0,0,185,186,5,93,0,0,186,40,1,0,0,0,187,188,5,
  	59,0,0,188,42,1,0,0,0,189,190,5,44,0,0,190,44,1,0,0,0,191,192,5,58,0,
  	0,192,46,1,0,0,0,193,194,7,3,0,0,194,48,1,0,0,0,195,196,7,4,0,0,196,50,
  	1,0,0,0,197,198,5,43,0,0,198,199,5,43,0,0,199,52,1,0,0,0,200,201,5,45,
  	0,0,201,202,5,45,0,0,202,54,1,0,0,0,203,204,5,33,0,0,204,56,1,0,0,0,205,
  	206,5,60,0,0,206,215,5,61,0,0,207,208,5,61,0,0,208,215,5,61,0,0,209,210,
  	5,62,0,0,210,215,5,61,0,0,211,215,7,5,0,0,212,213,5,33,0,0,213,215,5,
  	61,0,0,214,205,1,0,0,0,214,207,1,0,0,0,214,209,1,0,0,0,214,211,1,0,0,
  	0,214,212,1,0,0,0,215,58,1,0,0,0,216,217,5,38,0,0,217,221,5,38,0,0,218,
  	219,5,124,0,0,219,221,5,124,0,0,220,216,1,0,0,0,220,218,1,0,0,0,221,60,
  	1,0,0,0,222,223,5,61,0,0,223,62,1,0,0,0,224,228,7,6,0,0,225,227,7,7,0,
  	0,226,225,1,0,0,0,227,230,1,0,0,0,228,226,1,0,0,0,228,229,1,0,0,0,229,
  	64,1,0,0,0,230,228,1,0,0,0,231,235,7,6,0,0,232,234,7,7,0,0,233,232,1,
  	0,0,0,234,237,1,0,0,0,235,233,1,0,0,0,235,236,1,0,0,0,236,66,1,0,0,0,
  	237,235,1,0,0,0,238,240,7,8,0,0,239,238,1,0,0,0,240,241,1,0,0,0,241,239,
  	1,0,0,0,241,242,1,0,0,0,242,68,1,0,0,0,243,245,7,8,0,0,244,243,1,0,0,
  	0,245,246,1,0,0,0,246,244,1,0,0,0,246,247,1,0,0,0,247,255,1,0,0,0,248,
  	252,5,46,0,0,249,251,7,8,0,0,250,249,1,0,0,0,251,254,1,0,0,0,252,250,
  	1,0,0,0,252,253,1,0,0,0,253,256,1,0,0,0,254,252,1,0,0,0,255,248,1,0,0,
  	0,255,256,1,0,0,0,256,266,1,0,0,0,257,259,7,9,0,0,258,260,7,3,0,0,259,
  	258,1,0,0,0,259,260,1,0,0,0,260,262,1,0,0,0,261,263,7,8,0,0,262,261,1,
  	0,0,0,263,264,1,0,0,0,264,262,1,0,0,0,264,265,1,0,0,0,265,267,1,0,0,0,
  	266,257,1,0,0,0,266,267,1,0,0,0,267,281,1,0,0,0,268,270,5,46,0,0,269,
  	271,7,8,0,0,270,269,1,0,0,0,271,272,1,0,0,0,272,270,1,0,0,0,272,273,1,
  	0,0,0,273,281,1,0,0,0,274,276,7,8,0,0,275,274,1,0,0,0,276,277,1,0,0,0,
  	277,275,1,0,0,0,277,278,1,0,0,0,278,279,1,0,0,0,279,281,5,46,0,0,280,
  	244,1,0,0,0,280,268,1,0,0,0,280,275,1,0,0,0,281,70,1,0,0,0,21,0,77,89,
  	91,105,107,118,214,220,228,235,241,246,252,255,259,264,266,272,277,280,
  	4,1,0,0,6,0,0,1,1,1,1,2,2
  };
  staticData->serializedATN = antlr4::atn::SerializedATNView(serializedATNSegment, sizeof(serializedATNSegment) / sizeof(serializedATNSegment[0]));

  antlr4::atn::ATNDeserializer deserializer;
  staticData->atn = deserializer.deserialize(staticData->serializedATN);

  const size_t count = staticData->atn->getNumberOfDecisions();
  staticData->decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    staticData->decisionToDFA.emplace_back(staticData->atn->getDecisionState(i), i);
  }
  csubset_2205126lexerLexerStaticData = std::move(staticData);
}

}

CSubset_2205126Lexer::CSubset_2205126Lexer(CharStream *input) : Lexer(input) {
  CSubset_2205126Lexer::initialize();
  _interpreter = new atn::LexerATNSimulator(this, *csubset_2205126lexerLexerStaticData->atn, csubset_2205126lexerLexerStaticData->decisionToDFA, csubset_2205126lexerLexerStaticData->sharedContextCache);
}

CSubset_2205126Lexer::~CSubset_2205126Lexer() {
  delete _interpreter;
}

std::string CSubset_2205126Lexer::getGrammarFileName() const {
  return "CSubset_2205126.g4";
}

const std::vector<std::string>& CSubset_2205126Lexer::getRuleNames() const {
  return csubset_2205126lexerLexerStaticData->ruleNames;
}

const std::vector<std::string>& CSubset_2205126Lexer::getChannelNames() const {
  return csubset_2205126lexerLexerStaticData->channelNames;
}

const std::vector<std::string>& CSubset_2205126Lexer::getModeNames() const {
  return csubset_2205126lexerLexerStaticData->modeNames;
}

const dfa::Vocabulary& CSubset_2205126Lexer::getVocabulary() const {
  return csubset_2205126lexerLexerStaticData->vocabulary;
}

antlr4::atn::SerializedATNView CSubset_2205126Lexer::getSerializedATN() const {
  return csubset_2205126lexerLexerStaticData->serializedATN;
}

const atn::ATN& CSubset_2205126Lexer::getATN() const {
  return *csubset_2205126lexerLexerStaticData->atn;
}


void CSubset_2205126Lexer::action(RuleContext *context, size_t ruleIndex, size_t actionIndex) {
  switch (ruleIndex) {
    case 0: LINE_COMMENTAction(antlrcpp::downCast<antlr4::RuleContext *>(context), actionIndex); break;
    case 1: BLOCK_COMMENTAction(antlrcpp::downCast<antlr4::RuleContext *>(context), actionIndex); break;
    case 2: STRINGAction(antlrcpp::downCast<antlr4::RuleContext *>(context), actionIndex); break;

  default:
    break;
  }
}

void CSubset_2205126Lexer::LINE_COMMENTAction(antlr4::RuleContext *context, size_t actionIndex) {
  switch (actionIndex) {
    case 0: 
            writeIntoLexLogFile(
              "Line# " + std::to_string(getLine())
              + ": Token <SINGLE LINE COMMENT> Lexeme "
              + getText()
            );
         break;

  default:
    break;
  }
}

void CSubset_2205126Lexer::BLOCK_COMMENTAction(antlr4::RuleContext *context, size_t actionIndex) {
  switch (actionIndex) {
    case 1: 
          {
            std::string txt = getText();
            std::string content = txt.substr(2, txt.size() - 4);
            writeIntoLexLogFile(
              "Line# " + std::to_string(getLine())
              + ": Token <MULTI LINE COMMENT> Lexeme /*"
              + content + "*/"
            );
          }
         break;

  default:
    break;
  }
}

void CSubset_2205126Lexer::STRINGAction(antlr4::RuleContext *context, size_t actionIndex) {
  switch (actionIndex) {
    case 2: 
            writeIntoLexLogFile(
              "Line# " + std::to_string(getLine())
              + ": Token <STRING> Lexeme " + getText()
            );
         break;

  default:
    break;
  }
}



void CSubset_2205126Lexer::initialize() {
#if ANTLR4_USE_THREAD_LOCAL_CACHE
  csubset_2205126lexerLexerInitialize();
#else
  ::antlr4::internal::call_once(csubset_2205126lexerLexerOnceFlag, csubset_2205126lexerLexerInitialize);
#endif
}
