
// Generated from CSubset_2205126.g4 by ANTLR 4.13.2

#pragma once


#include "antlr4-runtime.h"
#include "CSubset_2205126Visitor.h"


/**
 * This class provides an empty implementation of CSubset_2205126Visitor, which can be
 * extended to create a visitor which only needs to handle a subset of the available methods.
 */
class  CSubset_2205126BaseVisitor : public CSubset_2205126Visitor {
public:

  virtual std::any visitStart(CSubset_2205126Parser::StartContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSingleUnit(CSubset_2205126Parser::SingleUnitContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitProgUnit(CSubset_2205126Parser::ProgUnitContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitUnitVarDecl(CSubset_2205126Parser::UnitVarDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitUnitFuncDecl(CSubset_2205126Parser::UnitFuncDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitUnitFuncDef(CSubset_2205126Parser::UnitFuncDefContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFuncDeclWithParams(CSubset_2205126Parser::FuncDeclWithParamsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFuncDeclNoParams(CSubset_2205126Parser::FuncDeclNoParamsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFuncDefWithParams(CSubset_2205126Parser::FuncDefWithParamsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFuncDefNoParams(CSubset_2205126Parser::FuncDefNoParamsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitParamListErrorSubMultiple(CSubset_2205126Parser::ParamListErrorSubMultipleContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitParamListSingle(CSubset_2205126Parser::ParamListSingleContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitParamListMultipleNoID(CSubset_2205126Parser::ParamListMultipleNoIDContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitParamListMultiple(CSubset_2205126Parser::ParamListMultipleContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitParamListSingleNoID(CSubset_2205126Parser::ParamListSingleNoIDContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitParamListErrorSub(CSubset_2205126Parser::ParamListErrorSubContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitCompoundStmtWithBody(CSubset_2205126Parser::CompoundStmtWithBodyContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitCompoundStmtEmpty(CSubset_2205126Parser::CompoundStmtEmptyContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitVarDecl(CSubset_2205126Parser::VarDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitTypeInt(CSubset_2205126Parser::TypeIntContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitTypeFloat(CSubset_2205126Parser::TypeFloatContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitTypeVoid(CSubset_2205126Parser::TypeVoidContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitDeclListSingle(CSubset_2205126Parser::DeclListSingleContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitDeclListMultipleArray(CSubset_2205126Parser::DeclListMultipleArrayContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitDeclListMultiple(CSubset_2205126Parser::DeclListMultipleContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitDeclListSingleArray(CSubset_2205126Parser::DeclListSingleArrayContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitDeclListErrorSub(CSubset_2205126Parser::DeclListErrorSubContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitDeclListErrorSubMultiple(CSubset_2205126Parser::DeclListErrorSubMultipleContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStmtsSingle(CSubset_2205126Parser::StmtsSingleContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStmtsMultiple(CSubset_2205126Parser::StmtsMultipleContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStmtVarDecl(CSubset_2205126Parser::StmtVarDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStmtExpr(CSubset_2205126Parser::StmtExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStmtCompound(CSubset_2205126Parser::StmtCompoundContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStmtFor(CSubset_2205126Parser::StmtForContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStmtIfElse(CSubset_2205126Parser::StmtIfElseContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStmtIf(CSubset_2205126Parser::StmtIfContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStmtWhile(CSubset_2205126Parser::StmtWhileContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStmtPrint(CSubset_2205126Parser::StmtPrintContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStmtReturn(CSubset_2205126Parser::StmtReturnContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStmtGoto(CSubset_2205126Parser::StmtGotoContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStmtLabel(CSubset_2205126Parser::StmtLabelContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitExprStmtEmpty(CSubset_2205126Parser::ExprStmtEmptyContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitExprStmtExpr(CSubset_2205126Parser::ExprStmtExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitExprStmtMissingSemicolon(CSubset_2205126Parser::ExprStmtMissingSemicolonContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitVarId(CSubset_2205126Parser::VarIdContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitVarArray(CSubset_2205126Parser::VarArrayContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitExprLogic(CSubset_2205126Parser::ExprLogicContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitExprAssign(CSubset_2205126Parser::ExprAssignContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitLogicRel(CSubset_2205126Parser::LogicRelContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitLogicOp(CSubset_2205126Parser::LogicOpContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitRelSimple(CSubset_2205126Parser::RelSimpleContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitRelOp(CSubset_2205126Parser::RelOpContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSimpTerm(CSubset_2205126Parser::SimpTermContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSimpAdd(CSubset_2205126Parser::SimpAddContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitTermUnary(CSubset_2205126Parser::TermUnaryContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitTermMul(CSubset_2205126Parser::TermMulContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitUnaryAdd(CSubset_2205126Parser::UnaryAddContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitUnaryNot(CSubset_2205126Parser::UnaryNotContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitUnaryFactor(CSubset_2205126Parser::UnaryFactorContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFactorVar(CSubset_2205126Parser::FactorVarContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFactorFuncCall(CSubset_2205126Parser::FactorFuncCallContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFactorParen(CSubset_2205126Parser::FactorParenContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFactorInt(CSubset_2205126Parser::FactorIntContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFactorFloat(CSubset_2205126Parser::FactorFloatContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFactorInc(CSubset_2205126Parser::FactorIncContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFactorDec(CSubset_2205126Parser::FactorDecContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitArgListArgs(CSubset_2205126Parser::ArgListArgsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitArgListEmpty(CSubset_2205126Parser::ArgListEmptyContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitArgsSingle(CSubset_2205126Parser::ArgsSingleContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitArgsMultiple(CSubset_2205126Parser::ArgsMultipleContext *ctx) override {
    return visitChildren(ctx);
  }


};

