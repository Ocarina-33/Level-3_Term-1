
// Generated from CSubset_2205126.g4 by ANTLR 4.13.2


#include "CSubset_2205126Visitor.h"

#include "CSubset_2205126Parser.h"


using namespace antlrcpp;

using namespace antlr4;

namespace {

struct CSubset_2205126ParserStaticData final {
  CSubset_2205126ParserStaticData(std::vector<std::string> ruleNames,
                        std::vector<std::string> literalNames,
                        std::vector<std::string> symbolicNames)
      : ruleNames(std::move(ruleNames)), literalNames(std::move(literalNames)),
        symbolicNames(std::move(symbolicNames)),
        vocabulary(this->literalNames, this->symbolicNames) {}

  CSubset_2205126ParserStaticData(const CSubset_2205126ParserStaticData&) = delete;
  CSubset_2205126ParserStaticData(CSubset_2205126ParserStaticData&&) = delete;
  CSubset_2205126ParserStaticData& operator=(const CSubset_2205126ParserStaticData&) = delete;
  CSubset_2205126ParserStaticData& operator=(CSubset_2205126ParserStaticData&&) = delete;

  std::vector<antlr4::dfa::DFA> decisionToDFA;
  antlr4::atn::PredictionContextCache sharedContextCache;
  const std::vector<std::string> ruleNames;
  const std::vector<std::string> literalNames;
  const std::vector<std::string> symbolicNames;
  const antlr4::dfa::Vocabulary vocabulary;
  antlr4::atn::SerializedATNView serializedATN;
  std::unique_ptr<antlr4::atn::ATN> atn;
};

::antlr4::internal::OnceFlag csubset_2205126ParserOnceFlag;
#if ANTLR4_USE_THREAD_LOCAL_CACHE
static thread_local
#endif
std::unique_ptr<CSubset_2205126ParserStaticData> csubset_2205126ParserStaticData = nullptr;

void csubset_2205126ParserInitialize() {
#if ANTLR4_USE_THREAD_LOCAL_CACHE
  if (csubset_2205126ParserStaticData != nullptr) {
    return;
  }
#else
  assert(csubset_2205126ParserStaticData == nullptr);
#endif
  auto staticData = std::make_unique<CSubset_2205126ParserStaticData>(
    std::vector<std::string>{
      "start", "program", "unit", "func_declaration", "func_definition", 
      "parameter_list", "compound_statement", "var_declaration", "type_specifier", 
      "declaration_list", "statements", "statement", "expression_statement", 
      "variable", "expression", "logic_expression", "rel_expression", "simple_expression", 
      "term", "unary_expression", "factor", "argument_list", "arguments"
    },
    std::vector<std::string>{
      "", "", "", "", "", "'if'", "'else'", "'for'", "'goto'", "'while'", 
      "'println'", "'return'", "'int'", "'float'", "'void'", "'('", "')'", 
      "'{'", "'}'", "'['", "']'", "';'", "','", "':'", "", "", "'++'", "'--'", 
      "'!'", "", "", "'='"
    },
    std::vector<std::string>{
      "", "LINE_COMMENT", "BLOCK_COMMENT", "STRING", "WS", "IF", "ELSE", 
      "FOR", "GOTO", "WHILE", "PRINTLN", "RETURN", "INT", "FLOAT", "VOID", 
      "LPAREN", "RPAREN", "LCURL", "RCURL", "LTHIRD", "RTHIRD", "SEMICOLON", 
      "COMMA", "COLON", "ADDOP", "MULOP", "INCOP", "DECOP", "NOT", "RELOP", 
      "LOGICOP", "ASSIGNOP", "ID", "LABEL", "CONST_INT", "CONST_FLOAT"
    }
  );
  static const int32_t serializedATNSegment[] = {
  	4,1,35,327,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,6,2,
  	7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,2,14,7,
  	14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,7,20,2,21,7,
  	21,2,22,7,22,1,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,5,1,55,8,1,10,1,12,1,58,
  	9,1,1,2,1,2,1,2,3,2,63,8,2,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,
  	3,1,3,1,3,3,3,78,8,3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,
  	1,4,3,4,93,8,4,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,3,5,103,8,5,1,5,1,5,1,
  	5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,5,5,118,8,5,10,5,12,5,121,9,
  	5,1,6,1,6,1,6,1,6,1,6,1,6,3,6,129,8,6,1,7,1,7,1,7,1,7,1,8,1,8,1,8,3,8,
  	138,8,8,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,3,9,149,8,9,1,9,1,9,1,9,1,
  	9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,5,9,165,8,9,10,9,12,9,168,9,
  	9,1,10,1,10,1,10,1,10,1,10,5,10,175,8,10,10,10,12,10,178,9,10,1,11,1,
  	11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,
  	11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,
  	11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,
  	11,1,11,3,11,225,8,11,1,12,1,12,1,12,1,12,1,12,3,12,232,8,12,1,13,1,13,
  	1,13,1,13,1,13,1,13,3,13,240,8,13,1,14,1,14,1,14,1,14,1,14,3,14,247,8,
  	14,1,15,1,15,1,15,1,15,1,15,3,15,254,8,15,1,16,1,16,1,16,1,16,1,16,3,
  	16,261,8,16,1,17,1,17,1,17,1,17,1,17,1,17,5,17,269,8,17,10,17,12,17,272,
  	9,17,1,18,1,18,1,18,1,18,1,18,1,18,5,18,280,8,18,10,18,12,18,283,9,18,
  	1,19,1,19,1,19,1,19,1,19,3,19,290,8,19,1,20,1,20,1,20,1,20,1,20,1,20,
  	1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,3,20,310,
  	8,20,1,21,1,21,3,21,314,8,21,1,22,1,22,1,22,1,22,1,22,1,22,5,22,322,8,
  	22,10,22,12,22,325,9,22,1,22,0,7,2,10,18,20,34,36,44,23,0,2,4,6,8,10,
  	12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,0,0,350,0,46,1,0,0,
  	0,2,49,1,0,0,0,4,62,1,0,0,0,6,77,1,0,0,0,8,92,1,0,0,0,10,102,1,0,0,0,
  	12,128,1,0,0,0,14,130,1,0,0,0,16,137,1,0,0,0,18,148,1,0,0,0,20,169,1,
  	0,0,0,22,224,1,0,0,0,24,231,1,0,0,0,26,239,1,0,0,0,28,246,1,0,0,0,30,
  	253,1,0,0,0,32,260,1,0,0,0,34,262,1,0,0,0,36,273,1,0,0,0,38,289,1,0,0,
  	0,40,309,1,0,0,0,42,313,1,0,0,0,44,315,1,0,0,0,46,47,3,2,1,0,47,48,5,
  	0,0,1,48,1,1,0,0,0,49,50,6,1,-1,0,50,51,3,4,2,0,51,56,1,0,0,0,52,53,10,
  	2,0,0,53,55,3,4,2,0,54,52,1,0,0,0,55,58,1,0,0,0,56,54,1,0,0,0,56,57,1,
  	0,0,0,57,3,1,0,0,0,58,56,1,0,0,0,59,63,3,14,7,0,60,63,3,6,3,0,61,63,3,
  	8,4,0,62,59,1,0,0,0,62,60,1,0,0,0,62,61,1,0,0,0,63,5,1,0,0,0,64,65,3,
  	16,8,0,65,66,5,32,0,0,66,67,5,15,0,0,67,68,3,10,5,0,68,69,5,16,0,0,69,
  	70,5,21,0,0,70,78,1,0,0,0,71,72,3,16,8,0,72,73,5,32,0,0,73,74,5,15,0,
  	0,74,75,5,16,0,0,75,76,5,21,0,0,76,78,1,0,0,0,77,64,1,0,0,0,77,71,1,0,
  	0,0,78,7,1,0,0,0,79,80,3,16,8,0,80,81,5,32,0,0,81,82,5,15,0,0,82,83,3,
  	10,5,0,83,84,5,16,0,0,84,85,3,12,6,0,85,93,1,0,0,0,86,87,3,16,8,0,87,
  	88,5,32,0,0,88,89,5,15,0,0,89,90,5,16,0,0,90,91,3,12,6,0,91,93,1,0,0,
  	0,92,79,1,0,0,0,92,86,1,0,0,0,93,9,1,0,0,0,94,95,6,5,-1,0,95,96,3,16,
  	8,0,96,97,5,32,0,0,97,103,1,0,0,0,98,103,3,16,8,0,99,100,3,16,8,0,100,
  	101,5,24,0,0,101,103,1,0,0,0,102,94,1,0,0,0,102,98,1,0,0,0,102,99,1,0,
  	0,0,103,119,1,0,0,0,104,105,10,6,0,0,105,106,5,22,0,0,106,107,3,16,8,
  	0,107,108,5,32,0,0,108,118,1,0,0,0,109,110,10,5,0,0,110,111,5,22,0,0,
  	111,118,3,16,8,0,112,113,10,1,0,0,113,114,5,22,0,0,114,115,3,16,8,0,115,
  	116,5,24,0,0,116,118,1,0,0,0,117,104,1,0,0,0,117,109,1,0,0,0,117,112,
  	1,0,0,0,118,121,1,0,0,0,119,117,1,0,0,0,119,120,1,0,0,0,120,11,1,0,0,
  	0,121,119,1,0,0,0,122,123,5,17,0,0,123,124,3,20,10,0,124,125,5,18,0,0,
  	125,129,1,0,0,0,126,127,5,17,0,0,127,129,5,18,0,0,128,122,1,0,0,0,128,
  	126,1,0,0,0,129,13,1,0,0,0,130,131,3,16,8,0,131,132,3,18,9,0,132,133,
  	5,21,0,0,133,15,1,0,0,0,134,138,5,12,0,0,135,138,5,13,0,0,136,138,5,14,
  	0,0,137,134,1,0,0,0,137,135,1,0,0,0,137,136,1,0,0,0,138,17,1,0,0,0,139,
  	140,6,9,-1,0,140,149,5,32,0,0,141,142,5,32,0,0,142,143,5,19,0,0,143,144,
  	5,34,0,0,144,149,5,20,0,0,145,146,5,32,0,0,146,147,5,24,0,0,147,149,5,
  	32,0,0,148,139,1,0,0,0,148,141,1,0,0,0,148,145,1,0,0,0,149,166,1,0,0,
  	0,150,151,10,6,0,0,151,152,5,22,0,0,152,165,5,32,0,0,153,154,10,5,0,0,
  	154,155,5,22,0,0,155,156,5,32,0,0,156,157,5,19,0,0,157,158,5,34,0,0,158,
  	165,5,20,0,0,159,160,10,1,0,0,160,161,5,22,0,0,161,162,5,32,0,0,162,163,
  	5,24,0,0,163,165,5,32,0,0,164,150,1,0,0,0,164,153,1,0,0,0,164,159,1,0,
  	0,0,165,168,1,0,0,0,166,164,1,0,0,0,166,167,1,0,0,0,167,19,1,0,0,0,168,
  	166,1,0,0,0,169,170,6,10,-1,0,170,171,3,22,11,0,171,176,1,0,0,0,172,173,
  	10,1,0,0,173,175,3,22,11,0,174,172,1,0,0,0,175,178,1,0,0,0,176,174,1,
  	0,0,0,176,177,1,0,0,0,177,21,1,0,0,0,178,176,1,0,0,0,179,225,3,14,7,0,
  	180,225,3,24,12,0,181,225,3,12,6,0,182,183,5,7,0,0,183,184,5,15,0,0,184,
  	185,3,24,12,0,185,186,3,24,12,0,186,187,3,28,14,0,187,188,5,16,0,0,188,
  	189,3,22,11,0,189,225,1,0,0,0,190,191,5,5,0,0,191,192,5,15,0,0,192,193,
  	3,28,14,0,193,194,5,16,0,0,194,195,3,22,11,0,195,196,5,6,0,0,196,197,
  	3,22,11,0,197,225,1,0,0,0,198,199,5,5,0,0,199,200,5,15,0,0,200,201,3,
  	28,14,0,201,202,5,16,0,0,202,203,3,22,11,0,203,225,1,0,0,0,204,205,5,
  	9,0,0,205,206,5,15,0,0,206,207,3,28,14,0,207,208,5,16,0,0,208,209,3,22,
  	11,0,209,225,1,0,0,0,210,211,5,10,0,0,211,212,5,15,0,0,212,213,5,32,0,
  	0,213,214,5,16,0,0,214,225,5,21,0,0,215,216,5,11,0,0,216,217,3,28,14,
  	0,217,218,5,21,0,0,218,225,1,0,0,0,219,220,5,8,0,0,220,221,5,33,0,0,221,
  	225,5,21,0,0,222,223,5,33,0,0,223,225,5,23,0,0,224,179,1,0,0,0,224,180,
  	1,0,0,0,224,181,1,0,0,0,224,182,1,0,0,0,224,190,1,0,0,0,224,198,1,0,0,
  	0,224,204,1,0,0,0,224,210,1,0,0,0,224,215,1,0,0,0,224,219,1,0,0,0,224,
  	222,1,0,0,0,225,23,1,0,0,0,226,232,5,21,0,0,227,228,3,28,14,0,228,229,
  	5,21,0,0,229,232,1,0,0,0,230,232,3,28,14,0,231,226,1,0,0,0,231,227,1,
  	0,0,0,231,230,1,0,0,0,232,25,1,0,0,0,233,240,5,32,0,0,234,235,5,32,0,
  	0,235,236,5,19,0,0,236,237,3,28,14,0,237,238,5,20,0,0,238,240,1,0,0,0,
  	239,233,1,0,0,0,239,234,1,0,0,0,240,27,1,0,0,0,241,247,3,30,15,0,242,
  	243,3,26,13,0,243,244,5,31,0,0,244,245,3,30,15,0,245,247,1,0,0,0,246,
  	241,1,0,0,0,246,242,1,0,0,0,247,29,1,0,0,0,248,254,3,32,16,0,249,250,
  	3,32,16,0,250,251,5,30,0,0,251,252,3,32,16,0,252,254,1,0,0,0,253,248,
  	1,0,0,0,253,249,1,0,0,0,254,31,1,0,0,0,255,261,3,34,17,0,256,257,3,34,
  	17,0,257,258,5,29,0,0,258,259,3,34,17,0,259,261,1,0,0,0,260,255,1,0,0,
  	0,260,256,1,0,0,0,261,33,1,0,0,0,262,263,6,17,-1,0,263,264,3,36,18,0,
  	264,270,1,0,0,0,265,266,10,1,0,0,266,267,5,24,0,0,267,269,3,36,18,0,268,
  	265,1,0,0,0,269,272,1,0,0,0,270,268,1,0,0,0,270,271,1,0,0,0,271,35,1,
  	0,0,0,272,270,1,0,0,0,273,274,6,18,-1,0,274,275,3,38,19,0,275,281,1,0,
  	0,0,276,277,10,1,0,0,277,278,5,25,0,0,278,280,3,38,19,0,279,276,1,0,0,
  	0,280,283,1,0,0,0,281,279,1,0,0,0,281,282,1,0,0,0,282,37,1,0,0,0,283,
  	281,1,0,0,0,284,285,5,24,0,0,285,290,3,38,19,0,286,287,5,28,0,0,287,290,
  	3,38,19,0,288,290,3,40,20,0,289,284,1,0,0,0,289,286,1,0,0,0,289,288,1,
  	0,0,0,290,39,1,0,0,0,291,310,3,26,13,0,292,293,5,32,0,0,293,294,5,15,
  	0,0,294,295,3,42,21,0,295,296,5,16,0,0,296,310,1,0,0,0,297,298,5,15,0,
  	0,298,299,3,28,14,0,299,300,5,16,0,0,300,310,1,0,0,0,301,310,5,34,0,0,
  	302,310,5,35,0,0,303,304,3,26,13,0,304,305,5,26,0,0,305,310,1,0,0,0,306,
  	307,3,26,13,0,307,308,5,27,0,0,308,310,1,0,0,0,309,291,1,0,0,0,309,292,
  	1,0,0,0,309,297,1,0,0,0,309,301,1,0,0,0,309,302,1,0,0,0,309,303,1,0,0,
  	0,309,306,1,0,0,0,310,41,1,0,0,0,311,314,3,44,22,0,312,314,1,0,0,0,313,
  	311,1,0,0,0,313,312,1,0,0,0,314,43,1,0,0,0,315,316,6,22,-1,0,316,317,
  	3,30,15,0,317,323,1,0,0,0,318,319,10,2,0,0,319,320,5,22,0,0,320,322,3,
  	30,15,0,321,318,1,0,0,0,322,325,1,0,0,0,323,321,1,0,0,0,323,324,1,0,0,
  	0,324,45,1,0,0,0,325,323,1,0,0,0,25,56,62,77,92,102,117,119,128,137,148,
  	164,166,176,224,231,239,246,253,260,270,281,289,309,313,323
  };
  staticData->serializedATN = antlr4::atn::SerializedATNView(serializedATNSegment, sizeof(serializedATNSegment) / sizeof(serializedATNSegment[0]));

  antlr4::atn::ATNDeserializer deserializer;
  staticData->atn = deserializer.deserialize(staticData->serializedATN);

  const size_t count = staticData->atn->getNumberOfDecisions();
  staticData->decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    staticData->decisionToDFA.emplace_back(staticData->atn->getDecisionState(i), i);
  }
  csubset_2205126ParserStaticData = std::move(staticData);
}

}

CSubset_2205126Parser::CSubset_2205126Parser(TokenStream *input) : CSubset_2205126Parser(input, antlr4::atn::ParserATNSimulatorOptions()) {}

CSubset_2205126Parser::CSubset_2205126Parser(TokenStream *input, const antlr4::atn::ParserATNSimulatorOptions &options) : Parser(input) {
  CSubset_2205126Parser::initialize();
  _interpreter = new atn::ParserATNSimulator(this, *csubset_2205126ParserStaticData->atn, csubset_2205126ParserStaticData->decisionToDFA, csubset_2205126ParserStaticData->sharedContextCache, options);
}

CSubset_2205126Parser::~CSubset_2205126Parser() {
  delete _interpreter;
}

const atn::ATN& CSubset_2205126Parser::getATN() const {
  return *csubset_2205126ParserStaticData->atn;
}

std::string CSubset_2205126Parser::getGrammarFileName() const {
  return "CSubset_2205126.g4";
}

const std::vector<std::string>& CSubset_2205126Parser::getRuleNames() const {
  return csubset_2205126ParserStaticData->ruleNames;
}

const dfa::Vocabulary& CSubset_2205126Parser::getVocabulary() const {
  return csubset_2205126ParserStaticData->vocabulary;
}

antlr4::atn::SerializedATNView CSubset_2205126Parser::getSerializedATN() const {
  return csubset_2205126ParserStaticData->serializedATN;
}


//----------------- StartContext ------------------------------------------------------------------

CSubset_2205126Parser::StartContext::StartContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

CSubset_2205126Parser::ProgramContext* CSubset_2205126Parser::StartContext::program() {
  return getRuleContext<CSubset_2205126Parser::ProgramContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::StartContext::EOF() {
  return getToken(CSubset_2205126Parser::EOF, 0);
}


size_t CSubset_2205126Parser::StartContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleStart;
}


std::any CSubset_2205126Parser::StartContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitStart(this);
  else
    return visitor->visitChildren(this);
}

CSubset_2205126Parser::StartContext* CSubset_2205126Parser::start() {
  StartContext *_localctx = _tracker.createInstance<StartContext>(_ctx, getState());
  enterRule(_localctx, 0, CSubset_2205126Parser::RuleStart);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(46);
    program(0);
    setState(47);
    match(CSubset_2205126Parser::EOF);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ProgramContext ------------------------------------------------------------------

CSubset_2205126Parser::ProgramContext::ProgramContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::ProgramContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleProgram;
}

void CSubset_2205126Parser::ProgramContext::copyFrom(ProgramContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- SingleUnitContext ------------------------------------------------------------------

CSubset_2205126Parser::UnitContext* CSubset_2205126Parser::SingleUnitContext::unit() {
  return getRuleContext<CSubset_2205126Parser::UnitContext>(0);
}

CSubset_2205126Parser::SingleUnitContext::SingleUnitContext(ProgramContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::SingleUnitContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitSingleUnit(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ProgUnitContext ------------------------------------------------------------------

CSubset_2205126Parser::ProgramContext* CSubset_2205126Parser::ProgUnitContext::program() {
  return getRuleContext<CSubset_2205126Parser::ProgramContext>(0);
}

CSubset_2205126Parser::UnitContext* CSubset_2205126Parser::ProgUnitContext::unit() {
  return getRuleContext<CSubset_2205126Parser::UnitContext>(0);
}

CSubset_2205126Parser::ProgUnitContext::ProgUnitContext(ProgramContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ProgUnitContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitProgUnit(this);
  else
    return visitor->visitChildren(this);
}

CSubset_2205126Parser::ProgramContext* CSubset_2205126Parser::program() {
   return program(0);
}

CSubset_2205126Parser::ProgramContext* CSubset_2205126Parser::program(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  CSubset_2205126Parser::ProgramContext *_localctx = _tracker.createInstance<ProgramContext>(_ctx, parentState);
  CSubset_2205126Parser::ProgramContext *previousContext = _localctx;
  (void)previousContext; // Silence compiler, in case the context is not used by generated code.
  size_t startState = 2;
  enterRecursionRule(_localctx, 2, CSubset_2205126Parser::RuleProgram, precedence);

    

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    _localctx = _tracker.createInstance<SingleUnitContext>(_localctx);
    _ctx = _localctx;
    previousContext = _localctx;

    setState(50);
    unit();
    _ctx->stop = _input->LT(-1);
    setState(56);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 0, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        auto newContext = _tracker.createInstance<ProgUnitContext>(_tracker.createInstance<ProgramContext>(parentContext, parentState));
        _localctx = newContext;
        pushNewRecursionContext(newContext, startState, RuleProgram);
        setState(52);

        if (!(precpred(_ctx, 2))) throw FailedPredicateException(this, "precpred(_ctx, 2)");
        setState(53);
        unit(); 
      }
      setState(58);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 0, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- UnitContext ------------------------------------------------------------------

CSubset_2205126Parser::UnitContext::UnitContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::UnitContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleUnit;
}

void CSubset_2205126Parser::UnitContext::copyFrom(UnitContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- UnitVarDeclContext ------------------------------------------------------------------

CSubset_2205126Parser::Var_declarationContext* CSubset_2205126Parser::UnitVarDeclContext::var_declaration() {
  return getRuleContext<CSubset_2205126Parser::Var_declarationContext>(0);
}

CSubset_2205126Parser::UnitVarDeclContext::UnitVarDeclContext(UnitContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::UnitVarDeclContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitUnitVarDecl(this);
  else
    return visitor->visitChildren(this);
}
//----------------- UnitFuncDefContext ------------------------------------------------------------------

CSubset_2205126Parser::Func_definitionContext* CSubset_2205126Parser::UnitFuncDefContext::func_definition() {
  return getRuleContext<CSubset_2205126Parser::Func_definitionContext>(0);
}

CSubset_2205126Parser::UnitFuncDefContext::UnitFuncDefContext(UnitContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::UnitFuncDefContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitUnitFuncDef(this);
  else
    return visitor->visitChildren(this);
}
//----------------- UnitFuncDeclContext ------------------------------------------------------------------

CSubset_2205126Parser::Func_declarationContext* CSubset_2205126Parser::UnitFuncDeclContext::func_declaration() {
  return getRuleContext<CSubset_2205126Parser::Func_declarationContext>(0);
}

CSubset_2205126Parser::UnitFuncDeclContext::UnitFuncDeclContext(UnitContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::UnitFuncDeclContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitUnitFuncDecl(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::UnitContext* CSubset_2205126Parser::unit() {
  UnitContext *_localctx = _tracker.createInstance<UnitContext>(_ctx, getState());
  enterRule(_localctx, 4, CSubset_2205126Parser::RuleUnit);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(62);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 1, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::UnitVarDeclContext>(_localctx);
      enterOuterAlt(_localctx, 1);
      setState(59);
      var_declaration();
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::UnitFuncDeclContext>(_localctx);
      enterOuterAlt(_localctx, 2);
      setState(60);
      func_declaration();
      break;
    }

    case 3: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::UnitFuncDefContext>(_localctx);
      enterOuterAlt(_localctx, 3);
      setState(61);
      func_definition();
      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Func_declarationContext ------------------------------------------------------------------

CSubset_2205126Parser::Func_declarationContext::Func_declarationContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::Func_declarationContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleFunc_declaration;
}

void CSubset_2205126Parser::Func_declarationContext::copyFrom(Func_declarationContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- FuncDeclWithParamsContext ------------------------------------------------------------------

CSubset_2205126Parser::Type_specifierContext* CSubset_2205126Parser::FuncDeclWithParamsContext::type_specifier() {
  return getRuleContext<CSubset_2205126Parser::Type_specifierContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::FuncDeclWithParamsContext::ID() {
  return getToken(CSubset_2205126Parser::ID, 0);
}

tree::TerminalNode* CSubset_2205126Parser::FuncDeclWithParamsContext::LPAREN() {
  return getToken(CSubset_2205126Parser::LPAREN, 0);
}

CSubset_2205126Parser::Parameter_listContext* CSubset_2205126Parser::FuncDeclWithParamsContext::parameter_list() {
  return getRuleContext<CSubset_2205126Parser::Parameter_listContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::FuncDeclWithParamsContext::RPAREN() {
  return getToken(CSubset_2205126Parser::RPAREN, 0);
}

tree::TerminalNode* CSubset_2205126Parser::FuncDeclWithParamsContext::SEMICOLON() {
  return getToken(CSubset_2205126Parser::SEMICOLON, 0);
}

CSubset_2205126Parser::FuncDeclWithParamsContext::FuncDeclWithParamsContext(Func_declarationContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::FuncDeclWithParamsContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitFuncDeclWithParams(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FuncDeclNoParamsContext ------------------------------------------------------------------

CSubset_2205126Parser::Type_specifierContext* CSubset_2205126Parser::FuncDeclNoParamsContext::type_specifier() {
  return getRuleContext<CSubset_2205126Parser::Type_specifierContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::FuncDeclNoParamsContext::ID() {
  return getToken(CSubset_2205126Parser::ID, 0);
}

tree::TerminalNode* CSubset_2205126Parser::FuncDeclNoParamsContext::LPAREN() {
  return getToken(CSubset_2205126Parser::LPAREN, 0);
}

tree::TerminalNode* CSubset_2205126Parser::FuncDeclNoParamsContext::RPAREN() {
  return getToken(CSubset_2205126Parser::RPAREN, 0);
}

tree::TerminalNode* CSubset_2205126Parser::FuncDeclNoParamsContext::SEMICOLON() {
  return getToken(CSubset_2205126Parser::SEMICOLON, 0);
}

CSubset_2205126Parser::FuncDeclNoParamsContext::FuncDeclNoParamsContext(Func_declarationContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::FuncDeclNoParamsContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitFuncDeclNoParams(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::Func_declarationContext* CSubset_2205126Parser::func_declaration() {
  Func_declarationContext *_localctx = _tracker.createInstance<Func_declarationContext>(_ctx, getState());
  enterRule(_localctx, 6, CSubset_2205126Parser::RuleFunc_declaration);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(77);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 2, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::FuncDeclWithParamsContext>(_localctx);
      enterOuterAlt(_localctx, 1);
      setState(64);
      type_specifier();
      setState(65);
      match(CSubset_2205126Parser::ID);
      setState(66);
      match(CSubset_2205126Parser::LPAREN);
      setState(67);
      parameter_list(0);
      setState(68);
      match(CSubset_2205126Parser::RPAREN);
      setState(69);
      match(CSubset_2205126Parser::SEMICOLON);
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::FuncDeclNoParamsContext>(_localctx);
      enterOuterAlt(_localctx, 2);
      setState(71);
      type_specifier();
      setState(72);
      match(CSubset_2205126Parser::ID);
      setState(73);
      match(CSubset_2205126Parser::LPAREN);
      setState(74);
      match(CSubset_2205126Parser::RPAREN);
      setState(75);
      match(CSubset_2205126Parser::SEMICOLON);
      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Func_definitionContext ------------------------------------------------------------------

CSubset_2205126Parser::Func_definitionContext::Func_definitionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::Func_definitionContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleFunc_definition;
}

void CSubset_2205126Parser::Func_definitionContext::copyFrom(Func_definitionContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- FuncDefNoParamsContext ------------------------------------------------------------------

CSubset_2205126Parser::Type_specifierContext* CSubset_2205126Parser::FuncDefNoParamsContext::type_specifier() {
  return getRuleContext<CSubset_2205126Parser::Type_specifierContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::FuncDefNoParamsContext::ID() {
  return getToken(CSubset_2205126Parser::ID, 0);
}

tree::TerminalNode* CSubset_2205126Parser::FuncDefNoParamsContext::LPAREN() {
  return getToken(CSubset_2205126Parser::LPAREN, 0);
}

tree::TerminalNode* CSubset_2205126Parser::FuncDefNoParamsContext::RPAREN() {
  return getToken(CSubset_2205126Parser::RPAREN, 0);
}

CSubset_2205126Parser::Compound_statementContext* CSubset_2205126Parser::FuncDefNoParamsContext::compound_statement() {
  return getRuleContext<CSubset_2205126Parser::Compound_statementContext>(0);
}

CSubset_2205126Parser::FuncDefNoParamsContext::FuncDefNoParamsContext(Func_definitionContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::FuncDefNoParamsContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitFuncDefNoParams(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FuncDefWithParamsContext ------------------------------------------------------------------

CSubset_2205126Parser::Type_specifierContext* CSubset_2205126Parser::FuncDefWithParamsContext::type_specifier() {
  return getRuleContext<CSubset_2205126Parser::Type_specifierContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::FuncDefWithParamsContext::ID() {
  return getToken(CSubset_2205126Parser::ID, 0);
}

tree::TerminalNode* CSubset_2205126Parser::FuncDefWithParamsContext::LPAREN() {
  return getToken(CSubset_2205126Parser::LPAREN, 0);
}

CSubset_2205126Parser::Parameter_listContext* CSubset_2205126Parser::FuncDefWithParamsContext::parameter_list() {
  return getRuleContext<CSubset_2205126Parser::Parameter_listContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::FuncDefWithParamsContext::RPAREN() {
  return getToken(CSubset_2205126Parser::RPAREN, 0);
}

CSubset_2205126Parser::Compound_statementContext* CSubset_2205126Parser::FuncDefWithParamsContext::compound_statement() {
  return getRuleContext<CSubset_2205126Parser::Compound_statementContext>(0);
}

CSubset_2205126Parser::FuncDefWithParamsContext::FuncDefWithParamsContext(Func_definitionContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::FuncDefWithParamsContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitFuncDefWithParams(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::Func_definitionContext* CSubset_2205126Parser::func_definition() {
  Func_definitionContext *_localctx = _tracker.createInstance<Func_definitionContext>(_ctx, getState());
  enterRule(_localctx, 8, CSubset_2205126Parser::RuleFunc_definition);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(92);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 3, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::FuncDefWithParamsContext>(_localctx);
      enterOuterAlt(_localctx, 1);
      setState(79);
      type_specifier();
      setState(80);
      match(CSubset_2205126Parser::ID);
      setState(81);
      match(CSubset_2205126Parser::LPAREN);
      setState(82);
      parameter_list(0);
      setState(83);
      match(CSubset_2205126Parser::RPAREN);
      setState(84);
      compound_statement();
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::FuncDefNoParamsContext>(_localctx);
      enterOuterAlt(_localctx, 2);
      setState(86);
      type_specifier();
      setState(87);
      match(CSubset_2205126Parser::ID);
      setState(88);
      match(CSubset_2205126Parser::LPAREN);
      setState(89);
      match(CSubset_2205126Parser::RPAREN);
      setState(90);
      compound_statement();
      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Parameter_listContext ------------------------------------------------------------------

CSubset_2205126Parser::Parameter_listContext::Parameter_listContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::Parameter_listContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleParameter_list;
}

void CSubset_2205126Parser::Parameter_listContext::copyFrom(Parameter_listContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- ParamListErrorSubMultipleContext ------------------------------------------------------------------

CSubset_2205126Parser::Parameter_listContext* CSubset_2205126Parser::ParamListErrorSubMultipleContext::parameter_list() {
  return getRuleContext<CSubset_2205126Parser::Parameter_listContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::ParamListErrorSubMultipleContext::COMMA() {
  return getToken(CSubset_2205126Parser::COMMA, 0);
}

CSubset_2205126Parser::Type_specifierContext* CSubset_2205126Parser::ParamListErrorSubMultipleContext::type_specifier() {
  return getRuleContext<CSubset_2205126Parser::Type_specifierContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::ParamListErrorSubMultipleContext::ADDOP() {
  return getToken(CSubset_2205126Parser::ADDOP, 0);
}

CSubset_2205126Parser::ParamListErrorSubMultipleContext::ParamListErrorSubMultipleContext(Parameter_listContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ParamListErrorSubMultipleContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitParamListErrorSubMultiple(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ParamListSingleContext ------------------------------------------------------------------

CSubset_2205126Parser::Type_specifierContext* CSubset_2205126Parser::ParamListSingleContext::type_specifier() {
  return getRuleContext<CSubset_2205126Parser::Type_specifierContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::ParamListSingleContext::ID() {
  return getToken(CSubset_2205126Parser::ID, 0);
}

CSubset_2205126Parser::ParamListSingleContext::ParamListSingleContext(Parameter_listContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ParamListSingleContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitParamListSingle(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ParamListMultipleNoIDContext ------------------------------------------------------------------

CSubset_2205126Parser::Parameter_listContext* CSubset_2205126Parser::ParamListMultipleNoIDContext::parameter_list() {
  return getRuleContext<CSubset_2205126Parser::Parameter_listContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::ParamListMultipleNoIDContext::COMMA() {
  return getToken(CSubset_2205126Parser::COMMA, 0);
}

CSubset_2205126Parser::Type_specifierContext* CSubset_2205126Parser::ParamListMultipleNoIDContext::type_specifier() {
  return getRuleContext<CSubset_2205126Parser::Type_specifierContext>(0);
}

CSubset_2205126Parser::ParamListMultipleNoIDContext::ParamListMultipleNoIDContext(Parameter_listContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ParamListMultipleNoIDContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitParamListMultipleNoID(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ParamListMultipleContext ------------------------------------------------------------------

CSubset_2205126Parser::Parameter_listContext* CSubset_2205126Parser::ParamListMultipleContext::parameter_list() {
  return getRuleContext<CSubset_2205126Parser::Parameter_listContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::ParamListMultipleContext::COMMA() {
  return getToken(CSubset_2205126Parser::COMMA, 0);
}

CSubset_2205126Parser::Type_specifierContext* CSubset_2205126Parser::ParamListMultipleContext::type_specifier() {
  return getRuleContext<CSubset_2205126Parser::Type_specifierContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::ParamListMultipleContext::ID() {
  return getToken(CSubset_2205126Parser::ID, 0);
}

CSubset_2205126Parser::ParamListMultipleContext::ParamListMultipleContext(Parameter_listContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ParamListMultipleContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitParamListMultiple(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ParamListSingleNoIDContext ------------------------------------------------------------------

CSubset_2205126Parser::Type_specifierContext* CSubset_2205126Parser::ParamListSingleNoIDContext::type_specifier() {
  return getRuleContext<CSubset_2205126Parser::Type_specifierContext>(0);
}

CSubset_2205126Parser::ParamListSingleNoIDContext::ParamListSingleNoIDContext(Parameter_listContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ParamListSingleNoIDContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitParamListSingleNoID(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ParamListErrorSubContext ------------------------------------------------------------------

CSubset_2205126Parser::Type_specifierContext* CSubset_2205126Parser::ParamListErrorSubContext::type_specifier() {
  return getRuleContext<CSubset_2205126Parser::Type_specifierContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::ParamListErrorSubContext::ADDOP() {
  return getToken(CSubset_2205126Parser::ADDOP, 0);
}

CSubset_2205126Parser::ParamListErrorSubContext::ParamListErrorSubContext(Parameter_listContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ParamListErrorSubContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitParamListErrorSub(this);
  else
    return visitor->visitChildren(this);
}

CSubset_2205126Parser::Parameter_listContext* CSubset_2205126Parser::parameter_list() {
   return parameter_list(0);
}

CSubset_2205126Parser::Parameter_listContext* CSubset_2205126Parser::parameter_list(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  CSubset_2205126Parser::Parameter_listContext *_localctx = _tracker.createInstance<Parameter_listContext>(_ctx, parentState);
  CSubset_2205126Parser::Parameter_listContext *previousContext = _localctx;
  (void)previousContext; // Silence compiler, in case the context is not used by generated code.
  size_t startState = 10;
  enterRecursionRule(_localctx, 10, CSubset_2205126Parser::RuleParameter_list, precedence);

    

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(102);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 4, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<ParamListSingleContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;

      setState(95);
      type_specifier();
      setState(96);
      match(CSubset_2205126Parser::ID);
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<ParamListSingleNoIDContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(98);
      type_specifier();
      break;
    }

    case 3: {
      _localctx = _tracker.createInstance<ParamListErrorSubContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(99);
      type_specifier();
      setState(100);
      match(CSubset_2205126Parser::ADDOP);
      break;
    }

    default:
      break;
    }
    _ctx->stop = _input->LT(-1);
    setState(119);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 6, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        setState(117);
        _errHandler->sync(this);
        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 5, _ctx)) {
        case 1: {
          auto newContext = _tracker.createInstance<ParamListMultipleContext>(_tracker.createInstance<Parameter_listContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleParameter_list);
          setState(104);

          if (!(precpred(_ctx, 6))) throw FailedPredicateException(this, "precpred(_ctx, 6)");
          setState(105);
          match(CSubset_2205126Parser::COMMA);
          setState(106);
          type_specifier();
          setState(107);
          match(CSubset_2205126Parser::ID);
          break;
        }

        case 2: {
          auto newContext = _tracker.createInstance<ParamListMultipleNoIDContext>(_tracker.createInstance<Parameter_listContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleParameter_list);
          setState(109);

          if (!(precpred(_ctx, 5))) throw FailedPredicateException(this, "precpred(_ctx, 5)");
          setState(110);
          match(CSubset_2205126Parser::COMMA);
          setState(111);
          type_specifier();
          break;
        }

        case 3: {
          auto newContext = _tracker.createInstance<ParamListErrorSubMultipleContext>(_tracker.createInstance<Parameter_listContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleParameter_list);
          setState(112);

          if (!(precpred(_ctx, 1))) throw FailedPredicateException(this, "precpred(_ctx, 1)");
          setState(113);
          match(CSubset_2205126Parser::COMMA);
          setState(114);
          type_specifier();
          setState(115);
          match(CSubset_2205126Parser::ADDOP);
          break;
        }

        default:
          break;
        } 
      }
      setState(121);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 6, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- Compound_statementContext ------------------------------------------------------------------

CSubset_2205126Parser::Compound_statementContext::Compound_statementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::Compound_statementContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleCompound_statement;
}

void CSubset_2205126Parser::Compound_statementContext::copyFrom(Compound_statementContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- CompoundStmtEmptyContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::CompoundStmtEmptyContext::LCURL() {
  return getToken(CSubset_2205126Parser::LCURL, 0);
}

tree::TerminalNode* CSubset_2205126Parser::CompoundStmtEmptyContext::RCURL() {
  return getToken(CSubset_2205126Parser::RCURL, 0);
}

CSubset_2205126Parser::CompoundStmtEmptyContext::CompoundStmtEmptyContext(Compound_statementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::CompoundStmtEmptyContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitCompoundStmtEmpty(this);
  else
    return visitor->visitChildren(this);
}
//----------------- CompoundStmtWithBodyContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::CompoundStmtWithBodyContext::LCURL() {
  return getToken(CSubset_2205126Parser::LCURL, 0);
}

CSubset_2205126Parser::StatementsContext* CSubset_2205126Parser::CompoundStmtWithBodyContext::statements() {
  return getRuleContext<CSubset_2205126Parser::StatementsContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::CompoundStmtWithBodyContext::RCURL() {
  return getToken(CSubset_2205126Parser::RCURL, 0);
}

CSubset_2205126Parser::CompoundStmtWithBodyContext::CompoundStmtWithBodyContext(Compound_statementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::CompoundStmtWithBodyContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitCompoundStmtWithBody(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::Compound_statementContext* CSubset_2205126Parser::compound_statement() {
  Compound_statementContext *_localctx = _tracker.createInstance<Compound_statementContext>(_ctx, getState());
  enterRule(_localctx, 12, CSubset_2205126Parser::RuleCompound_statement);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(128);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 7, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::CompoundStmtWithBodyContext>(_localctx);
      enterOuterAlt(_localctx, 1);
      setState(122);
      match(CSubset_2205126Parser::LCURL);
      setState(123);
      statements(0);
      setState(124);
      match(CSubset_2205126Parser::RCURL);
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::CompoundStmtEmptyContext>(_localctx);
      enterOuterAlt(_localctx, 2);
      setState(126);
      match(CSubset_2205126Parser::LCURL);
      setState(127);
      match(CSubset_2205126Parser::RCURL);
      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Var_declarationContext ------------------------------------------------------------------

CSubset_2205126Parser::Var_declarationContext::Var_declarationContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::Var_declarationContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleVar_declaration;
}

void CSubset_2205126Parser::Var_declarationContext::copyFrom(Var_declarationContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- VarDeclContext ------------------------------------------------------------------

CSubset_2205126Parser::Type_specifierContext* CSubset_2205126Parser::VarDeclContext::type_specifier() {
  return getRuleContext<CSubset_2205126Parser::Type_specifierContext>(0);
}

CSubset_2205126Parser::Declaration_listContext* CSubset_2205126Parser::VarDeclContext::declaration_list() {
  return getRuleContext<CSubset_2205126Parser::Declaration_listContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::VarDeclContext::SEMICOLON() {
  return getToken(CSubset_2205126Parser::SEMICOLON, 0);
}

CSubset_2205126Parser::VarDeclContext::VarDeclContext(Var_declarationContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::VarDeclContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitVarDecl(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::Var_declarationContext* CSubset_2205126Parser::var_declaration() {
  Var_declarationContext *_localctx = _tracker.createInstance<Var_declarationContext>(_ctx, getState());
  enterRule(_localctx, 14, CSubset_2205126Parser::RuleVar_declaration);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    _localctx = _tracker.createInstance<CSubset_2205126Parser::VarDeclContext>(_localctx);
    enterOuterAlt(_localctx, 1);
    setState(130);
    type_specifier();
    setState(131);
    declaration_list(0);
    setState(132);
    match(CSubset_2205126Parser::SEMICOLON);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Type_specifierContext ------------------------------------------------------------------

CSubset_2205126Parser::Type_specifierContext::Type_specifierContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::Type_specifierContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleType_specifier;
}

void CSubset_2205126Parser::Type_specifierContext::copyFrom(Type_specifierContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- TypeFloatContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::TypeFloatContext::FLOAT() {
  return getToken(CSubset_2205126Parser::FLOAT, 0);
}

CSubset_2205126Parser::TypeFloatContext::TypeFloatContext(Type_specifierContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::TypeFloatContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitTypeFloat(this);
  else
    return visitor->visitChildren(this);
}
//----------------- TypeVoidContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::TypeVoidContext::VOID() {
  return getToken(CSubset_2205126Parser::VOID, 0);
}

CSubset_2205126Parser::TypeVoidContext::TypeVoidContext(Type_specifierContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::TypeVoidContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitTypeVoid(this);
  else
    return visitor->visitChildren(this);
}
//----------------- TypeIntContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::TypeIntContext::INT() {
  return getToken(CSubset_2205126Parser::INT, 0);
}

CSubset_2205126Parser::TypeIntContext::TypeIntContext(Type_specifierContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::TypeIntContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitTypeInt(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::Type_specifierContext* CSubset_2205126Parser::type_specifier() {
  Type_specifierContext *_localctx = _tracker.createInstance<Type_specifierContext>(_ctx, getState());
  enterRule(_localctx, 16, CSubset_2205126Parser::RuleType_specifier);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(137);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case CSubset_2205126Parser::INT: {
        _localctx = _tracker.createInstance<CSubset_2205126Parser::TypeIntContext>(_localctx);
        enterOuterAlt(_localctx, 1);
        setState(134);
        match(CSubset_2205126Parser::INT);
        break;
      }

      case CSubset_2205126Parser::FLOAT: {
        _localctx = _tracker.createInstance<CSubset_2205126Parser::TypeFloatContext>(_localctx);
        enterOuterAlt(_localctx, 2);
        setState(135);
        match(CSubset_2205126Parser::FLOAT);
        break;
      }

      case CSubset_2205126Parser::VOID: {
        _localctx = _tracker.createInstance<CSubset_2205126Parser::TypeVoidContext>(_localctx);
        enterOuterAlt(_localctx, 3);
        setState(136);
        match(CSubset_2205126Parser::VOID);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Declaration_listContext ------------------------------------------------------------------

CSubset_2205126Parser::Declaration_listContext::Declaration_listContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::Declaration_listContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleDeclaration_list;
}

void CSubset_2205126Parser::Declaration_listContext::copyFrom(Declaration_listContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- DeclListSingleContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::DeclListSingleContext::ID() {
  return getToken(CSubset_2205126Parser::ID, 0);
}

CSubset_2205126Parser::DeclListSingleContext::DeclListSingleContext(Declaration_listContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::DeclListSingleContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitDeclListSingle(this);
  else
    return visitor->visitChildren(this);
}
//----------------- DeclListMultipleArrayContext ------------------------------------------------------------------

CSubset_2205126Parser::Declaration_listContext* CSubset_2205126Parser::DeclListMultipleArrayContext::declaration_list() {
  return getRuleContext<CSubset_2205126Parser::Declaration_listContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListMultipleArrayContext::COMMA() {
  return getToken(CSubset_2205126Parser::COMMA, 0);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListMultipleArrayContext::ID() {
  return getToken(CSubset_2205126Parser::ID, 0);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListMultipleArrayContext::LTHIRD() {
  return getToken(CSubset_2205126Parser::LTHIRD, 0);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListMultipleArrayContext::CONST_INT() {
  return getToken(CSubset_2205126Parser::CONST_INT, 0);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListMultipleArrayContext::RTHIRD() {
  return getToken(CSubset_2205126Parser::RTHIRD, 0);
}

CSubset_2205126Parser::DeclListMultipleArrayContext::DeclListMultipleArrayContext(Declaration_listContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::DeclListMultipleArrayContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitDeclListMultipleArray(this);
  else
    return visitor->visitChildren(this);
}
//----------------- DeclListMultipleContext ------------------------------------------------------------------

CSubset_2205126Parser::Declaration_listContext* CSubset_2205126Parser::DeclListMultipleContext::declaration_list() {
  return getRuleContext<CSubset_2205126Parser::Declaration_listContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListMultipleContext::COMMA() {
  return getToken(CSubset_2205126Parser::COMMA, 0);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListMultipleContext::ID() {
  return getToken(CSubset_2205126Parser::ID, 0);
}

CSubset_2205126Parser::DeclListMultipleContext::DeclListMultipleContext(Declaration_listContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::DeclListMultipleContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitDeclListMultiple(this);
  else
    return visitor->visitChildren(this);
}
//----------------- DeclListSingleArrayContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::DeclListSingleArrayContext::ID() {
  return getToken(CSubset_2205126Parser::ID, 0);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListSingleArrayContext::LTHIRD() {
  return getToken(CSubset_2205126Parser::LTHIRD, 0);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListSingleArrayContext::CONST_INT() {
  return getToken(CSubset_2205126Parser::CONST_INT, 0);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListSingleArrayContext::RTHIRD() {
  return getToken(CSubset_2205126Parser::RTHIRD, 0);
}

CSubset_2205126Parser::DeclListSingleArrayContext::DeclListSingleArrayContext(Declaration_listContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::DeclListSingleArrayContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitDeclListSingleArray(this);
  else
    return visitor->visitChildren(this);
}
//----------------- DeclListErrorSubContext ------------------------------------------------------------------

std::vector<tree::TerminalNode *> CSubset_2205126Parser::DeclListErrorSubContext::ID() {
  return getTokens(CSubset_2205126Parser::ID);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListErrorSubContext::ID(size_t i) {
  return getToken(CSubset_2205126Parser::ID, i);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListErrorSubContext::ADDOP() {
  return getToken(CSubset_2205126Parser::ADDOP, 0);
}

CSubset_2205126Parser::DeclListErrorSubContext::DeclListErrorSubContext(Declaration_listContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::DeclListErrorSubContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitDeclListErrorSub(this);
  else
    return visitor->visitChildren(this);
}
//----------------- DeclListErrorSubMultipleContext ------------------------------------------------------------------

CSubset_2205126Parser::Declaration_listContext* CSubset_2205126Parser::DeclListErrorSubMultipleContext::declaration_list() {
  return getRuleContext<CSubset_2205126Parser::Declaration_listContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListErrorSubMultipleContext::COMMA() {
  return getToken(CSubset_2205126Parser::COMMA, 0);
}

std::vector<tree::TerminalNode *> CSubset_2205126Parser::DeclListErrorSubMultipleContext::ID() {
  return getTokens(CSubset_2205126Parser::ID);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListErrorSubMultipleContext::ID(size_t i) {
  return getToken(CSubset_2205126Parser::ID, i);
}

tree::TerminalNode* CSubset_2205126Parser::DeclListErrorSubMultipleContext::ADDOP() {
  return getToken(CSubset_2205126Parser::ADDOP, 0);
}

CSubset_2205126Parser::DeclListErrorSubMultipleContext::DeclListErrorSubMultipleContext(Declaration_listContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::DeclListErrorSubMultipleContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitDeclListErrorSubMultiple(this);
  else
    return visitor->visitChildren(this);
}

CSubset_2205126Parser::Declaration_listContext* CSubset_2205126Parser::declaration_list() {
   return declaration_list(0);
}

CSubset_2205126Parser::Declaration_listContext* CSubset_2205126Parser::declaration_list(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  CSubset_2205126Parser::Declaration_listContext *_localctx = _tracker.createInstance<Declaration_listContext>(_ctx, parentState);
  CSubset_2205126Parser::Declaration_listContext *previousContext = _localctx;
  (void)previousContext; // Silence compiler, in case the context is not used by generated code.
  size_t startState = 18;
  enterRecursionRule(_localctx, 18, CSubset_2205126Parser::RuleDeclaration_list, precedence);

    

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(148);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 9, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<DeclListSingleContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;

      setState(140);
      match(CSubset_2205126Parser::ID);
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<DeclListSingleArrayContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(141);
      match(CSubset_2205126Parser::ID);
      setState(142);
      match(CSubset_2205126Parser::LTHIRD);
      setState(143);
      match(CSubset_2205126Parser::CONST_INT);
      setState(144);
      match(CSubset_2205126Parser::RTHIRD);
      break;
    }

    case 3: {
      _localctx = _tracker.createInstance<DeclListErrorSubContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(145);
      match(CSubset_2205126Parser::ID);
      setState(146);
      match(CSubset_2205126Parser::ADDOP);
      setState(147);
      match(CSubset_2205126Parser::ID);
      break;
    }

    default:
      break;
    }
    _ctx->stop = _input->LT(-1);
    setState(166);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 11, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        setState(164);
        _errHandler->sync(this);
        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 10, _ctx)) {
        case 1: {
          auto newContext = _tracker.createInstance<DeclListMultipleContext>(_tracker.createInstance<Declaration_listContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleDeclaration_list);
          setState(150);

          if (!(precpred(_ctx, 6))) throw FailedPredicateException(this, "precpred(_ctx, 6)");
          setState(151);
          match(CSubset_2205126Parser::COMMA);
          setState(152);
          match(CSubset_2205126Parser::ID);
          break;
        }

        case 2: {
          auto newContext = _tracker.createInstance<DeclListMultipleArrayContext>(_tracker.createInstance<Declaration_listContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleDeclaration_list);
          setState(153);

          if (!(precpred(_ctx, 5))) throw FailedPredicateException(this, "precpred(_ctx, 5)");
          setState(154);
          match(CSubset_2205126Parser::COMMA);
          setState(155);
          match(CSubset_2205126Parser::ID);
          setState(156);
          match(CSubset_2205126Parser::LTHIRD);
          setState(157);
          match(CSubset_2205126Parser::CONST_INT);
          setState(158);
          match(CSubset_2205126Parser::RTHIRD);
          break;
        }

        case 3: {
          auto newContext = _tracker.createInstance<DeclListErrorSubMultipleContext>(_tracker.createInstance<Declaration_listContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleDeclaration_list);
          setState(159);

          if (!(precpred(_ctx, 1))) throw FailedPredicateException(this, "precpred(_ctx, 1)");
          setState(160);
          match(CSubset_2205126Parser::COMMA);
          setState(161);
          match(CSubset_2205126Parser::ID);
          setState(162);
          match(CSubset_2205126Parser::ADDOP);
          setState(163);
          match(CSubset_2205126Parser::ID);
          break;
        }

        default:
          break;
        } 
      }
      setState(168);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 11, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- StatementsContext ------------------------------------------------------------------

CSubset_2205126Parser::StatementsContext::StatementsContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::StatementsContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleStatements;
}

void CSubset_2205126Parser::StatementsContext::copyFrom(StatementsContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- StmtsSingleContext ------------------------------------------------------------------

CSubset_2205126Parser::StatementContext* CSubset_2205126Parser::StmtsSingleContext::statement() {
  return getRuleContext<CSubset_2205126Parser::StatementContext>(0);
}

CSubset_2205126Parser::StmtsSingleContext::StmtsSingleContext(StatementsContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::StmtsSingleContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitStmtsSingle(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StmtsMultipleContext ------------------------------------------------------------------

CSubset_2205126Parser::StatementsContext* CSubset_2205126Parser::StmtsMultipleContext::statements() {
  return getRuleContext<CSubset_2205126Parser::StatementsContext>(0);
}

CSubset_2205126Parser::StatementContext* CSubset_2205126Parser::StmtsMultipleContext::statement() {
  return getRuleContext<CSubset_2205126Parser::StatementContext>(0);
}

CSubset_2205126Parser::StmtsMultipleContext::StmtsMultipleContext(StatementsContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::StmtsMultipleContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitStmtsMultiple(this);
  else
    return visitor->visitChildren(this);
}

CSubset_2205126Parser::StatementsContext* CSubset_2205126Parser::statements() {
   return statements(0);
}

CSubset_2205126Parser::StatementsContext* CSubset_2205126Parser::statements(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  CSubset_2205126Parser::StatementsContext *_localctx = _tracker.createInstance<StatementsContext>(_ctx, parentState);
  CSubset_2205126Parser::StatementsContext *previousContext = _localctx;
  (void)previousContext; // Silence compiler, in case the context is not used by generated code.
  size_t startState = 20;
  enterRecursionRule(_localctx, 20, CSubset_2205126Parser::RuleStatements, precedence);

    

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    _localctx = _tracker.createInstance<StmtsSingleContext>(_localctx);
    _ctx = _localctx;
    previousContext = _localctx;

    setState(170);
    statement();
    _ctx->stop = _input->LT(-1);
    setState(176);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 12, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        auto newContext = _tracker.createInstance<StmtsMultipleContext>(_tracker.createInstance<StatementsContext>(parentContext, parentState));
        _localctx = newContext;
        pushNewRecursionContext(newContext, startState, RuleStatements);
        setState(172);

        if (!(precpred(_ctx, 1))) throw FailedPredicateException(this, "precpred(_ctx, 1)");
        setState(173);
        statement(); 
      }
      setState(178);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 12, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- StatementContext ------------------------------------------------------------------

CSubset_2205126Parser::StatementContext::StatementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::StatementContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleStatement;
}

void CSubset_2205126Parser::StatementContext::copyFrom(StatementContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- StmtReturnContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::StmtReturnContext::RETURN() {
  return getToken(CSubset_2205126Parser::RETURN, 0);
}

CSubset_2205126Parser::ExpressionContext* CSubset_2205126Parser::StmtReturnContext::expression() {
  return getRuleContext<CSubset_2205126Parser::ExpressionContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtReturnContext::SEMICOLON() {
  return getToken(CSubset_2205126Parser::SEMICOLON, 0);
}

CSubset_2205126Parser::StmtReturnContext::StmtReturnContext(StatementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::StmtReturnContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitStmtReturn(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StmtCompoundContext ------------------------------------------------------------------

CSubset_2205126Parser::Compound_statementContext* CSubset_2205126Parser::StmtCompoundContext::compound_statement() {
  return getRuleContext<CSubset_2205126Parser::Compound_statementContext>(0);
}

CSubset_2205126Parser::StmtCompoundContext::StmtCompoundContext(StatementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::StmtCompoundContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitStmtCompound(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StmtGotoContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::StmtGotoContext::GOTO() {
  return getToken(CSubset_2205126Parser::GOTO, 0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtGotoContext::LABEL() {
  return getToken(CSubset_2205126Parser::LABEL, 0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtGotoContext::SEMICOLON() {
  return getToken(CSubset_2205126Parser::SEMICOLON, 0);
}

CSubset_2205126Parser::StmtGotoContext::StmtGotoContext(StatementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::StmtGotoContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitStmtGoto(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StmtLabelContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::StmtLabelContext::LABEL() {
  return getToken(CSubset_2205126Parser::LABEL, 0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtLabelContext::COLON() {
  return getToken(CSubset_2205126Parser::COLON, 0);
}

CSubset_2205126Parser::StmtLabelContext::StmtLabelContext(StatementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::StmtLabelContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitStmtLabel(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StmtVarDeclContext ------------------------------------------------------------------

CSubset_2205126Parser::Var_declarationContext* CSubset_2205126Parser::StmtVarDeclContext::var_declaration() {
  return getRuleContext<CSubset_2205126Parser::Var_declarationContext>(0);
}

CSubset_2205126Parser::StmtVarDeclContext::StmtVarDeclContext(StatementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::StmtVarDeclContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitStmtVarDecl(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StmtExprContext ------------------------------------------------------------------

CSubset_2205126Parser::Expression_statementContext* CSubset_2205126Parser::StmtExprContext::expression_statement() {
  return getRuleContext<CSubset_2205126Parser::Expression_statementContext>(0);
}

CSubset_2205126Parser::StmtExprContext::StmtExprContext(StatementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::StmtExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitStmtExpr(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StmtWhileContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::StmtWhileContext::WHILE() {
  return getToken(CSubset_2205126Parser::WHILE, 0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtWhileContext::LPAREN() {
  return getToken(CSubset_2205126Parser::LPAREN, 0);
}

CSubset_2205126Parser::ExpressionContext* CSubset_2205126Parser::StmtWhileContext::expression() {
  return getRuleContext<CSubset_2205126Parser::ExpressionContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtWhileContext::RPAREN() {
  return getToken(CSubset_2205126Parser::RPAREN, 0);
}

CSubset_2205126Parser::StatementContext* CSubset_2205126Parser::StmtWhileContext::statement() {
  return getRuleContext<CSubset_2205126Parser::StatementContext>(0);
}

CSubset_2205126Parser::StmtWhileContext::StmtWhileContext(StatementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::StmtWhileContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitStmtWhile(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StmtIfElseContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::StmtIfElseContext::IF() {
  return getToken(CSubset_2205126Parser::IF, 0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtIfElseContext::LPAREN() {
  return getToken(CSubset_2205126Parser::LPAREN, 0);
}

CSubset_2205126Parser::ExpressionContext* CSubset_2205126Parser::StmtIfElseContext::expression() {
  return getRuleContext<CSubset_2205126Parser::ExpressionContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtIfElseContext::RPAREN() {
  return getToken(CSubset_2205126Parser::RPAREN, 0);
}

std::vector<CSubset_2205126Parser::StatementContext *> CSubset_2205126Parser::StmtIfElseContext::statement() {
  return getRuleContexts<CSubset_2205126Parser::StatementContext>();
}

CSubset_2205126Parser::StatementContext* CSubset_2205126Parser::StmtIfElseContext::statement(size_t i) {
  return getRuleContext<CSubset_2205126Parser::StatementContext>(i);
}

tree::TerminalNode* CSubset_2205126Parser::StmtIfElseContext::ELSE() {
  return getToken(CSubset_2205126Parser::ELSE, 0);
}

CSubset_2205126Parser::StmtIfElseContext::StmtIfElseContext(StatementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::StmtIfElseContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitStmtIfElse(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StmtPrintContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::StmtPrintContext::PRINTLN() {
  return getToken(CSubset_2205126Parser::PRINTLN, 0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtPrintContext::LPAREN() {
  return getToken(CSubset_2205126Parser::LPAREN, 0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtPrintContext::ID() {
  return getToken(CSubset_2205126Parser::ID, 0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtPrintContext::RPAREN() {
  return getToken(CSubset_2205126Parser::RPAREN, 0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtPrintContext::SEMICOLON() {
  return getToken(CSubset_2205126Parser::SEMICOLON, 0);
}

CSubset_2205126Parser::StmtPrintContext::StmtPrintContext(StatementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::StmtPrintContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitStmtPrint(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StmtForContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::StmtForContext::FOR() {
  return getToken(CSubset_2205126Parser::FOR, 0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtForContext::LPAREN() {
  return getToken(CSubset_2205126Parser::LPAREN, 0);
}

std::vector<CSubset_2205126Parser::Expression_statementContext *> CSubset_2205126Parser::StmtForContext::expression_statement() {
  return getRuleContexts<CSubset_2205126Parser::Expression_statementContext>();
}

CSubset_2205126Parser::Expression_statementContext* CSubset_2205126Parser::StmtForContext::expression_statement(size_t i) {
  return getRuleContext<CSubset_2205126Parser::Expression_statementContext>(i);
}

CSubset_2205126Parser::ExpressionContext* CSubset_2205126Parser::StmtForContext::expression() {
  return getRuleContext<CSubset_2205126Parser::ExpressionContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtForContext::RPAREN() {
  return getToken(CSubset_2205126Parser::RPAREN, 0);
}

CSubset_2205126Parser::StatementContext* CSubset_2205126Parser::StmtForContext::statement() {
  return getRuleContext<CSubset_2205126Parser::StatementContext>(0);
}

CSubset_2205126Parser::StmtForContext::StmtForContext(StatementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::StmtForContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitStmtFor(this);
  else
    return visitor->visitChildren(this);
}
//----------------- StmtIfContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::StmtIfContext::IF() {
  return getToken(CSubset_2205126Parser::IF, 0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtIfContext::LPAREN() {
  return getToken(CSubset_2205126Parser::LPAREN, 0);
}

CSubset_2205126Parser::ExpressionContext* CSubset_2205126Parser::StmtIfContext::expression() {
  return getRuleContext<CSubset_2205126Parser::ExpressionContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::StmtIfContext::RPAREN() {
  return getToken(CSubset_2205126Parser::RPAREN, 0);
}

CSubset_2205126Parser::StatementContext* CSubset_2205126Parser::StmtIfContext::statement() {
  return getRuleContext<CSubset_2205126Parser::StatementContext>(0);
}

CSubset_2205126Parser::StmtIfContext::StmtIfContext(StatementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::StmtIfContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitStmtIf(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::StatementContext* CSubset_2205126Parser::statement() {
  StatementContext *_localctx = _tracker.createInstance<StatementContext>(_ctx, getState());
  enterRule(_localctx, 22, CSubset_2205126Parser::RuleStatement);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(224);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 13, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::StmtVarDeclContext>(_localctx);
      enterOuterAlt(_localctx, 1);
      setState(179);
      var_declaration();
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::StmtExprContext>(_localctx);
      enterOuterAlt(_localctx, 2);
      setState(180);
      expression_statement();
      break;
    }

    case 3: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::StmtCompoundContext>(_localctx);
      enterOuterAlt(_localctx, 3);
      setState(181);
      compound_statement();
      break;
    }

    case 4: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::StmtForContext>(_localctx);
      enterOuterAlt(_localctx, 4);
      setState(182);
      match(CSubset_2205126Parser::FOR);
      setState(183);
      match(CSubset_2205126Parser::LPAREN);
      setState(184);
      expression_statement();
      setState(185);
      expression_statement();
      setState(186);
      expression();
      setState(187);
      match(CSubset_2205126Parser::RPAREN);
      setState(188);
      statement();
      break;
    }

    case 5: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::StmtIfElseContext>(_localctx);
      enterOuterAlt(_localctx, 5);
      setState(190);
      match(CSubset_2205126Parser::IF);
      setState(191);
      match(CSubset_2205126Parser::LPAREN);
      setState(192);
      expression();
      setState(193);
      match(CSubset_2205126Parser::RPAREN);
      setState(194);
      statement();
      setState(195);
      match(CSubset_2205126Parser::ELSE);
      setState(196);
      statement();
      break;
    }

    case 6: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::StmtIfContext>(_localctx);
      enterOuterAlt(_localctx, 6);
      setState(198);
      match(CSubset_2205126Parser::IF);
      setState(199);
      match(CSubset_2205126Parser::LPAREN);
      setState(200);
      expression();
      setState(201);
      match(CSubset_2205126Parser::RPAREN);
      setState(202);
      statement();
      break;
    }

    case 7: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::StmtWhileContext>(_localctx);
      enterOuterAlt(_localctx, 7);
      setState(204);
      match(CSubset_2205126Parser::WHILE);
      setState(205);
      match(CSubset_2205126Parser::LPAREN);
      setState(206);
      expression();
      setState(207);
      match(CSubset_2205126Parser::RPAREN);
      setState(208);
      statement();
      break;
    }

    case 8: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::StmtPrintContext>(_localctx);
      enterOuterAlt(_localctx, 8);
      setState(210);
      match(CSubset_2205126Parser::PRINTLN);
      setState(211);
      match(CSubset_2205126Parser::LPAREN);
      setState(212);
      match(CSubset_2205126Parser::ID);
      setState(213);
      match(CSubset_2205126Parser::RPAREN);
      setState(214);
      match(CSubset_2205126Parser::SEMICOLON);
      break;
    }

    case 9: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::StmtReturnContext>(_localctx);
      enterOuterAlt(_localctx, 9);
      setState(215);
      match(CSubset_2205126Parser::RETURN);
      setState(216);
      expression();
      setState(217);
      match(CSubset_2205126Parser::SEMICOLON);
      break;
    }

    case 10: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::StmtGotoContext>(_localctx);
      enterOuterAlt(_localctx, 10);
      setState(219);
      match(CSubset_2205126Parser::GOTO);
      setState(220);
      match(CSubset_2205126Parser::LABEL);
      setState(221);
      match(CSubset_2205126Parser::SEMICOLON);
      break;
    }

    case 11: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::StmtLabelContext>(_localctx);
      enterOuterAlt(_localctx, 11);
      setState(222);
      match(CSubset_2205126Parser::LABEL);
      setState(223);
      match(CSubset_2205126Parser::COLON);
      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Expression_statementContext ------------------------------------------------------------------

CSubset_2205126Parser::Expression_statementContext::Expression_statementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::Expression_statementContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleExpression_statement;
}

void CSubset_2205126Parser::Expression_statementContext::copyFrom(Expression_statementContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- ExprStmtMissingSemicolonContext ------------------------------------------------------------------

CSubset_2205126Parser::ExpressionContext* CSubset_2205126Parser::ExprStmtMissingSemicolonContext::expression() {
  return getRuleContext<CSubset_2205126Parser::ExpressionContext>(0);
}

CSubset_2205126Parser::ExprStmtMissingSemicolonContext::ExprStmtMissingSemicolonContext(Expression_statementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ExprStmtMissingSemicolonContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitExprStmtMissingSemicolon(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprStmtEmptyContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::ExprStmtEmptyContext::SEMICOLON() {
  return getToken(CSubset_2205126Parser::SEMICOLON, 0);
}

CSubset_2205126Parser::ExprStmtEmptyContext::ExprStmtEmptyContext(Expression_statementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ExprStmtEmptyContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitExprStmtEmpty(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprStmtExprContext ------------------------------------------------------------------

CSubset_2205126Parser::ExpressionContext* CSubset_2205126Parser::ExprStmtExprContext::expression() {
  return getRuleContext<CSubset_2205126Parser::ExpressionContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::ExprStmtExprContext::SEMICOLON() {
  return getToken(CSubset_2205126Parser::SEMICOLON, 0);
}

CSubset_2205126Parser::ExprStmtExprContext::ExprStmtExprContext(Expression_statementContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ExprStmtExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitExprStmtExpr(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::Expression_statementContext* CSubset_2205126Parser::expression_statement() {
  Expression_statementContext *_localctx = _tracker.createInstance<Expression_statementContext>(_ctx, getState());
  enterRule(_localctx, 24, CSubset_2205126Parser::RuleExpression_statement);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(231);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 14, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::ExprStmtEmptyContext>(_localctx);
      enterOuterAlt(_localctx, 1);
      setState(226);
      match(CSubset_2205126Parser::SEMICOLON);
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::ExprStmtExprContext>(_localctx);
      enterOuterAlt(_localctx, 2);
      setState(227);
      expression();
      setState(228);
      match(CSubset_2205126Parser::SEMICOLON);
      break;
    }

    case 3: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::ExprStmtMissingSemicolonContext>(_localctx);
      enterOuterAlt(_localctx, 3);
      setState(230);
      expression();
      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- VariableContext ------------------------------------------------------------------

CSubset_2205126Parser::VariableContext::VariableContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::VariableContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleVariable;
}

void CSubset_2205126Parser::VariableContext::copyFrom(VariableContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- VarArrayContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::VarArrayContext::ID() {
  return getToken(CSubset_2205126Parser::ID, 0);
}

tree::TerminalNode* CSubset_2205126Parser::VarArrayContext::LTHIRD() {
  return getToken(CSubset_2205126Parser::LTHIRD, 0);
}

CSubset_2205126Parser::ExpressionContext* CSubset_2205126Parser::VarArrayContext::expression() {
  return getRuleContext<CSubset_2205126Parser::ExpressionContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::VarArrayContext::RTHIRD() {
  return getToken(CSubset_2205126Parser::RTHIRD, 0);
}

CSubset_2205126Parser::VarArrayContext::VarArrayContext(VariableContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::VarArrayContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitVarArray(this);
  else
    return visitor->visitChildren(this);
}
//----------------- VarIdContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::VarIdContext::ID() {
  return getToken(CSubset_2205126Parser::ID, 0);
}

CSubset_2205126Parser::VarIdContext::VarIdContext(VariableContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::VarIdContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitVarId(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::VariableContext* CSubset_2205126Parser::variable() {
  VariableContext *_localctx = _tracker.createInstance<VariableContext>(_ctx, getState());
  enterRule(_localctx, 26, CSubset_2205126Parser::RuleVariable);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(239);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 15, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::VarIdContext>(_localctx);
      enterOuterAlt(_localctx, 1);
      setState(233);
      match(CSubset_2205126Parser::ID);
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::VarArrayContext>(_localctx);
      enterOuterAlt(_localctx, 2);
      setState(234);
      match(CSubset_2205126Parser::ID);
      setState(235);
      match(CSubset_2205126Parser::LTHIRD);
      setState(236);
      expression();
      setState(237);
      match(CSubset_2205126Parser::RTHIRD);
      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExpressionContext ------------------------------------------------------------------

CSubset_2205126Parser::ExpressionContext::ExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::ExpressionContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleExpression;
}

void CSubset_2205126Parser::ExpressionContext::copyFrom(ExpressionContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- ExprAssignContext ------------------------------------------------------------------

CSubset_2205126Parser::VariableContext* CSubset_2205126Parser::ExprAssignContext::variable() {
  return getRuleContext<CSubset_2205126Parser::VariableContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::ExprAssignContext::ASSIGNOP() {
  return getToken(CSubset_2205126Parser::ASSIGNOP, 0);
}

CSubset_2205126Parser::Logic_expressionContext* CSubset_2205126Parser::ExprAssignContext::logic_expression() {
  return getRuleContext<CSubset_2205126Parser::Logic_expressionContext>(0);
}

CSubset_2205126Parser::ExprAssignContext::ExprAssignContext(ExpressionContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ExprAssignContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitExprAssign(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ExprLogicContext ------------------------------------------------------------------

CSubset_2205126Parser::Logic_expressionContext* CSubset_2205126Parser::ExprLogicContext::logic_expression() {
  return getRuleContext<CSubset_2205126Parser::Logic_expressionContext>(0);
}

CSubset_2205126Parser::ExprLogicContext::ExprLogicContext(ExpressionContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ExprLogicContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitExprLogic(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::ExpressionContext* CSubset_2205126Parser::expression() {
  ExpressionContext *_localctx = _tracker.createInstance<ExpressionContext>(_ctx, getState());
  enterRule(_localctx, 28, CSubset_2205126Parser::RuleExpression);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(246);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 16, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::ExprLogicContext>(_localctx);
      enterOuterAlt(_localctx, 1);
      setState(241);
      logic_expression();
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::ExprAssignContext>(_localctx);
      enterOuterAlt(_localctx, 2);
      setState(242);
      variable();
      setState(243);
      match(CSubset_2205126Parser::ASSIGNOP);
      setState(244);
      logic_expression();
      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Logic_expressionContext ------------------------------------------------------------------

CSubset_2205126Parser::Logic_expressionContext::Logic_expressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::Logic_expressionContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleLogic_expression;
}

void CSubset_2205126Parser::Logic_expressionContext::copyFrom(Logic_expressionContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- LogicRelContext ------------------------------------------------------------------

CSubset_2205126Parser::Rel_expressionContext* CSubset_2205126Parser::LogicRelContext::rel_expression() {
  return getRuleContext<CSubset_2205126Parser::Rel_expressionContext>(0);
}

CSubset_2205126Parser::LogicRelContext::LogicRelContext(Logic_expressionContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::LogicRelContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitLogicRel(this);
  else
    return visitor->visitChildren(this);
}
//----------------- LogicOpContext ------------------------------------------------------------------

std::vector<CSubset_2205126Parser::Rel_expressionContext *> CSubset_2205126Parser::LogicOpContext::rel_expression() {
  return getRuleContexts<CSubset_2205126Parser::Rel_expressionContext>();
}

CSubset_2205126Parser::Rel_expressionContext* CSubset_2205126Parser::LogicOpContext::rel_expression(size_t i) {
  return getRuleContext<CSubset_2205126Parser::Rel_expressionContext>(i);
}

tree::TerminalNode* CSubset_2205126Parser::LogicOpContext::LOGICOP() {
  return getToken(CSubset_2205126Parser::LOGICOP, 0);
}

CSubset_2205126Parser::LogicOpContext::LogicOpContext(Logic_expressionContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::LogicOpContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitLogicOp(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::Logic_expressionContext* CSubset_2205126Parser::logic_expression() {
  Logic_expressionContext *_localctx = _tracker.createInstance<Logic_expressionContext>(_ctx, getState());
  enterRule(_localctx, 30, CSubset_2205126Parser::RuleLogic_expression);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(253);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 17, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::LogicRelContext>(_localctx);
      enterOuterAlt(_localctx, 1);
      setState(248);
      rel_expression();
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::LogicOpContext>(_localctx);
      enterOuterAlt(_localctx, 2);
      setState(249);
      rel_expression();
      setState(250);
      match(CSubset_2205126Parser::LOGICOP);
      setState(251);
      rel_expression();
      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Rel_expressionContext ------------------------------------------------------------------

CSubset_2205126Parser::Rel_expressionContext::Rel_expressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::Rel_expressionContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleRel_expression;
}

void CSubset_2205126Parser::Rel_expressionContext::copyFrom(Rel_expressionContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- RelOpContext ------------------------------------------------------------------

std::vector<CSubset_2205126Parser::Simple_expressionContext *> CSubset_2205126Parser::RelOpContext::simple_expression() {
  return getRuleContexts<CSubset_2205126Parser::Simple_expressionContext>();
}

CSubset_2205126Parser::Simple_expressionContext* CSubset_2205126Parser::RelOpContext::simple_expression(size_t i) {
  return getRuleContext<CSubset_2205126Parser::Simple_expressionContext>(i);
}

tree::TerminalNode* CSubset_2205126Parser::RelOpContext::RELOP() {
  return getToken(CSubset_2205126Parser::RELOP, 0);
}

CSubset_2205126Parser::RelOpContext::RelOpContext(Rel_expressionContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::RelOpContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitRelOp(this);
  else
    return visitor->visitChildren(this);
}
//----------------- RelSimpleContext ------------------------------------------------------------------

CSubset_2205126Parser::Simple_expressionContext* CSubset_2205126Parser::RelSimpleContext::simple_expression() {
  return getRuleContext<CSubset_2205126Parser::Simple_expressionContext>(0);
}

CSubset_2205126Parser::RelSimpleContext::RelSimpleContext(Rel_expressionContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::RelSimpleContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitRelSimple(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::Rel_expressionContext* CSubset_2205126Parser::rel_expression() {
  Rel_expressionContext *_localctx = _tracker.createInstance<Rel_expressionContext>(_ctx, getState());
  enterRule(_localctx, 32, CSubset_2205126Parser::RuleRel_expression);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(260);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 18, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::RelSimpleContext>(_localctx);
      enterOuterAlt(_localctx, 1);
      setState(255);
      simple_expression(0);
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::RelOpContext>(_localctx);
      enterOuterAlt(_localctx, 2);
      setState(256);
      simple_expression(0);
      setState(257);
      match(CSubset_2205126Parser::RELOP);
      setState(258);
      simple_expression(0);
      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Simple_expressionContext ------------------------------------------------------------------

CSubset_2205126Parser::Simple_expressionContext::Simple_expressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::Simple_expressionContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleSimple_expression;
}

void CSubset_2205126Parser::Simple_expressionContext::copyFrom(Simple_expressionContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- SimpTermContext ------------------------------------------------------------------

CSubset_2205126Parser::TermContext* CSubset_2205126Parser::SimpTermContext::term() {
  return getRuleContext<CSubset_2205126Parser::TermContext>(0);
}

CSubset_2205126Parser::SimpTermContext::SimpTermContext(Simple_expressionContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::SimpTermContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitSimpTerm(this);
  else
    return visitor->visitChildren(this);
}
//----------------- SimpAddContext ------------------------------------------------------------------

CSubset_2205126Parser::Simple_expressionContext* CSubset_2205126Parser::SimpAddContext::simple_expression() {
  return getRuleContext<CSubset_2205126Parser::Simple_expressionContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::SimpAddContext::ADDOP() {
  return getToken(CSubset_2205126Parser::ADDOP, 0);
}

CSubset_2205126Parser::TermContext* CSubset_2205126Parser::SimpAddContext::term() {
  return getRuleContext<CSubset_2205126Parser::TermContext>(0);
}

CSubset_2205126Parser::SimpAddContext::SimpAddContext(Simple_expressionContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::SimpAddContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitSimpAdd(this);
  else
    return visitor->visitChildren(this);
}

CSubset_2205126Parser::Simple_expressionContext* CSubset_2205126Parser::simple_expression() {
   return simple_expression(0);
}

CSubset_2205126Parser::Simple_expressionContext* CSubset_2205126Parser::simple_expression(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  CSubset_2205126Parser::Simple_expressionContext *_localctx = _tracker.createInstance<Simple_expressionContext>(_ctx, parentState);
  CSubset_2205126Parser::Simple_expressionContext *previousContext = _localctx;
  (void)previousContext; // Silence compiler, in case the context is not used by generated code.
  size_t startState = 34;
  enterRecursionRule(_localctx, 34, CSubset_2205126Parser::RuleSimple_expression, precedence);

    

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    _localctx = _tracker.createInstance<SimpTermContext>(_localctx);
    _ctx = _localctx;
    previousContext = _localctx;

    setState(263);
    term(0);
    _ctx->stop = _input->LT(-1);
    setState(270);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 19, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        auto newContext = _tracker.createInstance<SimpAddContext>(_tracker.createInstance<Simple_expressionContext>(parentContext, parentState));
        _localctx = newContext;
        pushNewRecursionContext(newContext, startState, RuleSimple_expression);
        setState(265);

        if (!(precpred(_ctx, 1))) throw FailedPredicateException(this, "precpred(_ctx, 1)");
        setState(266);
        match(CSubset_2205126Parser::ADDOP);
        setState(267);
        term(0); 
      }
      setState(272);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 19, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- TermContext ------------------------------------------------------------------

CSubset_2205126Parser::TermContext::TermContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::TermContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleTerm;
}

void CSubset_2205126Parser::TermContext::copyFrom(TermContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- TermUnaryContext ------------------------------------------------------------------

CSubset_2205126Parser::Unary_expressionContext* CSubset_2205126Parser::TermUnaryContext::unary_expression() {
  return getRuleContext<CSubset_2205126Parser::Unary_expressionContext>(0);
}

CSubset_2205126Parser::TermUnaryContext::TermUnaryContext(TermContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::TermUnaryContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitTermUnary(this);
  else
    return visitor->visitChildren(this);
}
//----------------- TermMulContext ------------------------------------------------------------------

CSubset_2205126Parser::TermContext* CSubset_2205126Parser::TermMulContext::term() {
  return getRuleContext<CSubset_2205126Parser::TermContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::TermMulContext::MULOP() {
  return getToken(CSubset_2205126Parser::MULOP, 0);
}

CSubset_2205126Parser::Unary_expressionContext* CSubset_2205126Parser::TermMulContext::unary_expression() {
  return getRuleContext<CSubset_2205126Parser::Unary_expressionContext>(0);
}

CSubset_2205126Parser::TermMulContext::TermMulContext(TermContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::TermMulContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitTermMul(this);
  else
    return visitor->visitChildren(this);
}

CSubset_2205126Parser::TermContext* CSubset_2205126Parser::term() {
   return term(0);
}

CSubset_2205126Parser::TermContext* CSubset_2205126Parser::term(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  CSubset_2205126Parser::TermContext *_localctx = _tracker.createInstance<TermContext>(_ctx, parentState);
  CSubset_2205126Parser::TermContext *previousContext = _localctx;
  (void)previousContext; // Silence compiler, in case the context is not used by generated code.
  size_t startState = 36;
  enterRecursionRule(_localctx, 36, CSubset_2205126Parser::RuleTerm, precedence);

    

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    _localctx = _tracker.createInstance<TermUnaryContext>(_localctx);
    _ctx = _localctx;
    previousContext = _localctx;

    setState(274);
    unary_expression();
    _ctx->stop = _input->LT(-1);
    setState(281);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 20, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        auto newContext = _tracker.createInstance<TermMulContext>(_tracker.createInstance<TermContext>(parentContext, parentState));
        _localctx = newContext;
        pushNewRecursionContext(newContext, startState, RuleTerm);
        setState(276);

        if (!(precpred(_ctx, 1))) throw FailedPredicateException(this, "precpred(_ctx, 1)");
        setState(277);
        match(CSubset_2205126Parser::MULOP);
        setState(278);
        unary_expression(); 
      }
      setState(283);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 20, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- Unary_expressionContext ------------------------------------------------------------------

CSubset_2205126Parser::Unary_expressionContext::Unary_expressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::Unary_expressionContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleUnary_expression;
}

void CSubset_2205126Parser::Unary_expressionContext::copyFrom(Unary_expressionContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- UnaryNotContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::UnaryNotContext::NOT() {
  return getToken(CSubset_2205126Parser::NOT, 0);
}

CSubset_2205126Parser::Unary_expressionContext* CSubset_2205126Parser::UnaryNotContext::unary_expression() {
  return getRuleContext<CSubset_2205126Parser::Unary_expressionContext>(0);
}

CSubset_2205126Parser::UnaryNotContext::UnaryNotContext(Unary_expressionContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::UnaryNotContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitUnaryNot(this);
  else
    return visitor->visitChildren(this);
}
//----------------- UnaryFactorContext ------------------------------------------------------------------

CSubset_2205126Parser::FactorContext* CSubset_2205126Parser::UnaryFactorContext::factor() {
  return getRuleContext<CSubset_2205126Parser::FactorContext>(0);
}

CSubset_2205126Parser::UnaryFactorContext::UnaryFactorContext(Unary_expressionContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::UnaryFactorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitUnaryFactor(this);
  else
    return visitor->visitChildren(this);
}
//----------------- UnaryAddContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::UnaryAddContext::ADDOP() {
  return getToken(CSubset_2205126Parser::ADDOP, 0);
}

CSubset_2205126Parser::Unary_expressionContext* CSubset_2205126Parser::UnaryAddContext::unary_expression() {
  return getRuleContext<CSubset_2205126Parser::Unary_expressionContext>(0);
}

CSubset_2205126Parser::UnaryAddContext::UnaryAddContext(Unary_expressionContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::UnaryAddContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitUnaryAdd(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::Unary_expressionContext* CSubset_2205126Parser::unary_expression() {
  Unary_expressionContext *_localctx = _tracker.createInstance<Unary_expressionContext>(_ctx, getState());
  enterRule(_localctx, 38, CSubset_2205126Parser::RuleUnary_expression);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(289);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case CSubset_2205126Parser::ADDOP: {
        _localctx = _tracker.createInstance<CSubset_2205126Parser::UnaryAddContext>(_localctx);
        enterOuterAlt(_localctx, 1);
        setState(284);
        match(CSubset_2205126Parser::ADDOP);
        setState(285);
        unary_expression();
        break;
      }

      case CSubset_2205126Parser::NOT: {
        _localctx = _tracker.createInstance<CSubset_2205126Parser::UnaryNotContext>(_localctx);
        enterOuterAlt(_localctx, 2);
        setState(286);
        match(CSubset_2205126Parser::NOT);
        setState(287);
        unary_expression();
        break;
      }

      case CSubset_2205126Parser::LPAREN:
      case CSubset_2205126Parser::ID:
      case CSubset_2205126Parser::CONST_INT:
      case CSubset_2205126Parser::CONST_FLOAT: {
        _localctx = _tracker.createInstance<CSubset_2205126Parser::UnaryFactorContext>(_localctx);
        enterOuterAlt(_localctx, 3);
        setState(288);
        factor();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FactorContext ------------------------------------------------------------------

CSubset_2205126Parser::FactorContext::FactorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::FactorContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleFactor;
}

void CSubset_2205126Parser::FactorContext::copyFrom(FactorContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- FactorFuncCallContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::FactorFuncCallContext::ID() {
  return getToken(CSubset_2205126Parser::ID, 0);
}

tree::TerminalNode* CSubset_2205126Parser::FactorFuncCallContext::LPAREN() {
  return getToken(CSubset_2205126Parser::LPAREN, 0);
}

CSubset_2205126Parser::Argument_listContext* CSubset_2205126Parser::FactorFuncCallContext::argument_list() {
  return getRuleContext<CSubset_2205126Parser::Argument_listContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::FactorFuncCallContext::RPAREN() {
  return getToken(CSubset_2205126Parser::RPAREN, 0);
}

CSubset_2205126Parser::FactorFuncCallContext::FactorFuncCallContext(FactorContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::FactorFuncCallContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitFactorFuncCall(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FactorIntContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::FactorIntContext::CONST_INT() {
  return getToken(CSubset_2205126Parser::CONST_INT, 0);
}

CSubset_2205126Parser::FactorIntContext::FactorIntContext(FactorContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::FactorIntContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitFactorInt(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FactorParenContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::FactorParenContext::LPAREN() {
  return getToken(CSubset_2205126Parser::LPAREN, 0);
}

CSubset_2205126Parser::ExpressionContext* CSubset_2205126Parser::FactorParenContext::expression() {
  return getRuleContext<CSubset_2205126Parser::ExpressionContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::FactorParenContext::RPAREN() {
  return getToken(CSubset_2205126Parser::RPAREN, 0);
}

CSubset_2205126Parser::FactorParenContext::FactorParenContext(FactorContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::FactorParenContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitFactorParen(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FactorDecContext ------------------------------------------------------------------

CSubset_2205126Parser::VariableContext* CSubset_2205126Parser::FactorDecContext::variable() {
  return getRuleContext<CSubset_2205126Parser::VariableContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::FactorDecContext::DECOP() {
  return getToken(CSubset_2205126Parser::DECOP, 0);
}

CSubset_2205126Parser::FactorDecContext::FactorDecContext(FactorContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::FactorDecContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitFactorDec(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FactorFloatContext ------------------------------------------------------------------

tree::TerminalNode* CSubset_2205126Parser::FactorFloatContext::CONST_FLOAT() {
  return getToken(CSubset_2205126Parser::CONST_FLOAT, 0);
}

CSubset_2205126Parser::FactorFloatContext::FactorFloatContext(FactorContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::FactorFloatContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitFactorFloat(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FactorIncContext ------------------------------------------------------------------

CSubset_2205126Parser::VariableContext* CSubset_2205126Parser::FactorIncContext::variable() {
  return getRuleContext<CSubset_2205126Parser::VariableContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::FactorIncContext::INCOP() {
  return getToken(CSubset_2205126Parser::INCOP, 0);
}

CSubset_2205126Parser::FactorIncContext::FactorIncContext(FactorContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::FactorIncContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitFactorInc(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FactorVarContext ------------------------------------------------------------------

CSubset_2205126Parser::VariableContext* CSubset_2205126Parser::FactorVarContext::variable() {
  return getRuleContext<CSubset_2205126Parser::VariableContext>(0);
}

CSubset_2205126Parser::FactorVarContext::FactorVarContext(FactorContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::FactorVarContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitFactorVar(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::FactorContext* CSubset_2205126Parser::factor() {
  FactorContext *_localctx = _tracker.createInstance<FactorContext>(_ctx, getState());
  enterRule(_localctx, 40, CSubset_2205126Parser::RuleFactor);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(309);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 22, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::FactorVarContext>(_localctx);
      enterOuterAlt(_localctx, 1);
      setState(291);
      variable();
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::FactorFuncCallContext>(_localctx);
      enterOuterAlt(_localctx, 2);
      setState(292);
      match(CSubset_2205126Parser::ID);
      setState(293);
      match(CSubset_2205126Parser::LPAREN);
      setState(294);
      argument_list();
      setState(295);
      match(CSubset_2205126Parser::RPAREN);
      break;
    }

    case 3: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::FactorParenContext>(_localctx);
      enterOuterAlt(_localctx, 3);
      setState(297);
      match(CSubset_2205126Parser::LPAREN);
      setState(298);
      expression();
      setState(299);
      match(CSubset_2205126Parser::RPAREN);
      break;
    }

    case 4: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::FactorIntContext>(_localctx);
      enterOuterAlt(_localctx, 4);
      setState(301);
      match(CSubset_2205126Parser::CONST_INT);
      break;
    }

    case 5: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::FactorFloatContext>(_localctx);
      enterOuterAlt(_localctx, 5);
      setState(302);
      match(CSubset_2205126Parser::CONST_FLOAT);
      break;
    }

    case 6: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::FactorIncContext>(_localctx);
      enterOuterAlt(_localctx, 6);
      setState(303);
      variable();
      setState(304);
      match(CSubset_2205126Parser::INCOP);
      break;
    }

    case 7: {
      _localctx = _tracker.createInstance<CSubset_2205126Parser::FactorDecContext>(_localctx);
      enterOuterAlt(_localctx, 7);
      setState(306);
      variable();
      setState(307);
      match(CSubset_2205126Parser::DECOP);
      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Argument_listContext ------------------------------------------------------------------

CSubset_2205126Parser::Argument_listContext::Argument_listContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::Argument_listContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleArgument_list;
}

void CSubset_2205126Parser::Argument_listContext::copyFrom(Argument_listContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- ArgListEmptyContext ------------------------------------------------------------------

CSubset_2205126Parser::ArgListEmptyContext::ArgListEmptyContext(Argument_listContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ArgListEmptyContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitArgListEmpty(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ArgListArgsContext ------------------------------------------------------------------

CSubset_2205126Parser::ArgumentsContext* CSubset_2205126Parser::ArgListArgsContext::arguments() {
  return getRuleContext<CSubset_2205126Parser::ArgumentsContext>(0);
}

CSubset_2205126Parser::ArgListArgsContext::ArgListArgsContext(Argument_listContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ArgListArgsContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitArgListArgs(this);
  else
    return visitor->visitChildren(this);
}
CSubset_2205126Parser::Argument_listContext* CSubset_2205126Parser::argument_list() {
  Argument_listContext *_localctx = _tracker.createInstance<Argument_listContext>(_ctx, getState());
  enterRule(_localctx, 42, CSubset_2205126Parser::RuleArgument_list);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(313);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case CSubset_2205126Parser::LPAREN:
      case CSubset_2205126Parser::ADDOP:
      case CSubset_2205126Parser::NOT:
      case CSubset_2205126Parser::ID:
      case CSubset_2205126Parser::CONST_INT:
      case CSubset_2205126Parser::CONST_FLOAT: {
        _localctx = _tracker.createInstance<CSubset_2205126Parser::ArgListArgsContext>(_localctx);
        enterOuterAlt(_localctx, 1);
        setState(311);
        arguments(0);
        break;
      }

      case CSubset_2205126Parser::RPAREN: {
        _localctx = _tracker.createInstance<CSubset_2205126Parser::ArgListEmptyContext>(_localctx);
        enterOuterAlt(_localctx, 2);

        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ArgumentsContext ------------------------------------------------------------------

CSubset_2205126Parser::ArgumentsContext::ArgumentsContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t CSubset_2205126Parser::ArgumentsContext::getRuleIndex() const {
  return CSubset_2205126Parser::RuleArguments;
}

void CSubset_2205126Parser::ArgumentsContext::copyFrom(ArgumentsContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- ArgsSingleContext ------------------------------------------------------------------

CSubset_2205126Parser::Logic_expressionContext* CSubset_2205126Parser::ArgsSingleContext::logic_expression() {
  return getRuleContext<CSubset_2205126Parser::Logic_expressionContext>(0);
}

CSubset_2205126Parser::ArgsSingleContext::ArgsSingleContext(ArgumentsContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ArgsSingleContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitArgsSingle(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ArgsMultipleContext ------------------------------------------------------------------

CSubset_2205126Parser::ArgumentsContext* CSubset_2205126Parser::ArgsMultipleContext::arguments() {
  return getRuleContext<CSubset_2205126Parser::ArgumentsContext>(0);
}

tree::TerminalNode* CSubset_2205126Parser::ArgsMultipleContext::COMMA() {
  return getToken(CSubset_2205126Parser::COMMA, 0);
}

CSubset_2205126Parser::Logic_expressionContext* CSubset_2205126Parser::ArgsMultipleContext::logic_expression() {
  return getRuleContext<CSubset_2205126Parser::Logic_expressionContext>(0);
}

CSubset_2205126Parser::ArgsMultipleContext::ArgsMultipleContext(ArgumentsContext *ctx) { copyFrom(ctx); }


std::any CSubset_2205126Parser::ArgsMultipleContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<CSubset_2205126Visitor*>(visitor))
    return parserVisitor->visitArgsMultiple(this);
  else
    return visitor->visitChildren(this);
}

CSubset_2205126Parser::ArgumentsContext* CSubset_2205126Parser::arguments() {
   return arguments(0);
}

CSubset_2205126Parser::ArgumentsContext* CSubset_2205126Parser::arguments(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  CSubset_2205126Parser::ArgumentsContext *_localctx = _tracker.createInstance<ArgumentsContext>(_ctx, parentState);
  CSubset_2205126Parser::ArgumentsContext *previousContext = _localctx;
  (void)previousContext; // Silence compiler, in case the context is not used by generated code.
  size_t startState = 44;
  enterRecursionRule(_localctx, 44, CSubset_2205126Parser::RuleArguments, precedence);

    

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    _localctx = _tracker.createInstance<ArgsSingleContext>(_localctx);
    _ctx = _localctx;
    previousContext = _localctx;

    setState(316);
    logic_expression();
    _ctx->stop = _input->LT(-1);
    setState(323);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 24, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        auto newContext = _tracker.createInstance<ArgsMultipleContext>(_tracker.createInstance<ArgumentsContext>(parentContext, parentState));
        _localctx = newContext;
        pushNewRecursionContext(newContext, startState, RuleArguments);
        setState(318);

        if (!(precpred(_ctx, 2))) throw FailedPredicateException(this, "precpred(_ctx, 2)");
        setState(319);
        match(CSubset_2205126Parser::COMMA);
        setState(320);
        logic_expression(); 
      }
      setState(325);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 24, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

bool CSubset_2205126Parser::sempred(RuleContext *context, size_t ruleIndex, size_t predicateIndex) {
  switch (ruleIndex) {
    case 1: return programSempred(antlrcpp::downCast<ProgramContext *>(context), predicateIndex);
    case 5: return parameter_listSempred(antlrcpp::downCast<Parameter_listContext *>(context), predicateIndex);
    case 9: return declaration_listSempred(antlrcpp::downCast<Declaration_listContext *>(context), predicateIndex);
    case 10: return statementsSempred(antlrcpp::downCast<StatementsContext *>(context), predicateIndex);
    case 17: return simple_expressionSempred(antlrcpp::downCast<Simple_expressionContext *>(context), predicateIndex);
    case 18: return termSempred(antlrcpp::downCast<TermContext *>(context), predicateIndex);
    case 22: return argumentsSempred(antlrcpp::downCast<ArgumentsContext *>(context), predicateIndex);

  default:
    break;
  }
  return true;
}

bool CSubset_2205126Parser::programSempred(ProgramContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 0: return precpred(_ctx, 2);

  default:
    break;
  }
  return true;
}

bool CSubset_2205126Parser::parameter_listSempred(Parameter_listContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 1: return precpred(_ctx, 6);
    case 2: return precpred(_ctx, 5);
    case 3: return precpred(_ctx, 1);

  default:
    break;
  }
  return true;
}

bool CSubset_2205126Parser::declaration_listSempred(Declaration_listContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 4: return precpred(_ctx, 6);
    case 5: return precpred(_ctx, 5);
    case 6: return precpred(_ctx, 1);

  default:
    break;
  }
  return true;
}

bool CSubset_2205126Parser::statementsSempred(StatementsContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 7: return precpred(_ctx, 1);

  default:
    break;
  }
  return true;
}

bool CSubset_2205126Parser::simple_expressionSempred(Simple_expressionContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 8: return precpred(_ctx, 1);

  default:
    break;
  }
  return true;
}

bool CSubset_2205126Parser::termSempred(TermContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 9: return precpred(_ctx, 1);

  default:
    break;
  }
  return true;
}

bool CSubset_2205126Parser::argumentsSempred(ArgumentsContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 10: return precpred(_ctx, 2);

  default:
    break;
  }
  return true;
}

void CSubset_2205126Parser::initialize() {
#if ANTLR4_USE_THREAD_LOCAL_CACHE
  csubset_2205126ParserInitialize();
#else
  ::antlr4::internal::call_once(csubset_2205126ParserOnceFlag, csubset_2205126ParserInitialize);
#endif
}
