
    #pragma once
    #include <iostream>
    #include <fstream>
    #include <string>

    extern std::ofstream lexLogFile;


// Generated from Lexer_2205126.g4 by ANTLR 4.13.2

#pragma once


#include "antlr4-runtime.h"




class  Lexer_2205126 : public antlr4::Lexer {
public:
  enum {
    LINE_COMMENT = 1, BLOCK_COMMENT = 2, STRING = 3, WS = 4, IF = 5, ELSE = 6, 
    FOR = 7, GOTO = 8, WHILE = 9, PRINTLN = 10, RETURN = 11, INT = 12, FLOAT = 13, 
    VOID = 14, LPAREN = 15, RPAREN = 16, LCURL = 17, RCURL = 18, LTHIRD = 19, 
    RTHIRD = 20, SEMICOLON = 21, COMMA = 22, COLON = 23, ADDOP = 24, MULOP = 25, 
    INCOP = 26, DECOP = 27, NOT = 28, RELOP = 29, LOGICOP = 30, ASSIGNOP = 31, 
    ID = 32, LABEL = 33, CONST_INT = 34, CONST_FLOAT = 35
  };

  explicit Lexer_2205126(antlr4::CharStream *input);

  ~Lexer_2205126() override;


      void writeIntoLexLogFile(const std::string &message) {
          if (!lexLogFile.is_open()) {
              lexLogFile.open("log.txt", std::ios::app);
              if (!lexLogFile) {
                  std::cerr << "Error opening log.txt" << std::endl;
                  return;
              }
          }
          lexLogFile << message << std::endl;
          lexLogFile.flush();
      }


  std::string getGrammarFileName() const override;

  const std::vector<std::string>& getRuleNames() const override;

  const std::vector<std::string>& getChannelNames() const override;

  const std::vector<std::string>& getModeNames() const override;

  const antlr4::dfa::Vocabulary& getVocabulary() const override;

  antlr4::atn::SerializedATNView getSerializedATN() const override;

  const antlr4::atn::ATN& getATN() const override;

  void action(antlr4::RuleContext *context, size_t ruleIndex, size_t actionIndex) override;

  // By default the static state used to implement the lexer is lazily initialized during the first
  // call to the constructor. You can call this function if you wish to initialize the static state
  // ahead of time.
  static void initialize();

private:

  // Individual action functions triggered by action() above.
  void LINE_COMMENTAction(antlr4::RuleContext *context, size_t actionIndex);
  void BLOCK_COMMENTAction(antlr4::RuleContext *context, size_t actionIndex);
  void STRINGAction(antlr4::RuleContext *context, size_t actionIndex);

  // Individual semantic predicate functions triggered by sempred() above.

};

